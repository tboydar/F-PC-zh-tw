
-- eM24
-- em24a	03jun00cht, expand cpu16 to 24 bits
-- em24e1	11jun00cht, add sks, skr, lld, lst
-- em24e2	11jun00cht, use named signals in muxes
-- em24e3	13jun00cht, bidirectional data bus
-- em24e4	15jun00cht, rearrange opcode, add test_in, test_out
-- em24f1	10jul00cht, new instruction set, failed
-- em24f2	11jul00cht, start from e4, proceed slowly
-- em24f3	14jul00cht, consolidate incrementors p,x,y. no good.
-- em24f4	14jul00cht, eliminate p-mux, no good
-- em24f5	14jul00cht, change shr for no-cost uart, decy now is next.
--		16jul00cht, change depth to 15.
--		17jul00cht, change depth back to 7, delete test_in/out.
-- em24f6	06aug00cht, xy/sr_depth, change n to s.
-- em25a1	06aug00cht, use core generator for stacks.
-- em25a2	07aug00cht, use ramb4_s16_s16 for stacks.
-- em25a3	09aug00cht, add code to memory
-- em25a4	10aug00cht, eni to replace bbt
-- em25a5	14aug00cht, code in memory
-- em25a6	14aug00cht, change to ldrp and strp, fix slot
--		useattribute for code initialization
--		16aug00cht, test Diagnose
-- em25a7	18aug00cht, eliminate r,x,y registers
-- cpu24a1	01sep00cht, adapted from em25a7 and cpu16
-- cpu24b	07nov00cht, real tests
--			change x back to a.
--			put stacks back to logic.
-- p24c		02dec00cht, 6 bit instructions, mul, div, interrupts
--		05dec00cht, move to vcx1000e
-- p24d		06dec00cht, move to vcx300
-- p24c		interrupt removed, iload and uload fixed.  working.
-- p24e		13dec00cht, test core-gen ram and mif file.
-- p16b		11jan01cht, make p16
-- p16c		18jan01cht, expand stacks to 32 levels.

library ieee;
use ieee.std_logic_1164.all;
use IEEE.std_logic_arith.all;
use IEEE.std_logic_misc.all;
use IEEE.std_logic_unsigned.all;

-- synopsys translate_off
Library XilinxCoreLib;
-- synopsys translate_on


entity cpu16 is 
	generic(width: integer := 16);
	port(
	holdosc0: out std_logic;
	clk,arst,uart_in: in std_logic;
	icode: out std_logic_vector(4 downto 0);
	interrupt: in std_logic_vector(4 downto 0);
	uart_out,auload: out std_logic;
	data: out std_logic_vector(15 downto 0);
	address: out std_logic_vector(11 downto 0));
end entity cpu16;

-- synopsys translate_off
configuration configcpu16 of cpu16 is
     for archcpu16
	for all : p16ram use entity XilinxCoreLib.C_MEM_SP_BLOCK_V1_0(behavioral)
		generic map(
			c_has_en => 1,
			c_rst_polarity => 1,
			c_clk_polarity => 1,
			c_width => 16,
			c_has_do => 1,
			c_has_di => 1,
			c_en_polarity => 1,
			c_has_we => 1,
			c_has_rst => 1,
			c_address_width => 12,
			c_read_mif => 1,
			c_depth => 4096,
			c_pipe_stages => 0,
			c_mem_init_radix => 16,
			c_default_data => "0",
			c_mem_init_file => "E:\Xilinx\active\projects\p16b\log.f",
			c_we_polarity => 1,
			c_generate_mif => 1);
	end for;
     end for;
 end configcpu16;
-- synopsys translate_on

architecture archcpu16 of cpu16 is

component p16ram
	port (
	addr: IN std_logic_VECTOR(11 downto 0);
	clk: IN std_logic;
	di: IN std_logic_VECTOR(15 downto 0);
	we: IN std_logic;
	en: IN std_logic;
	rst: IN std_logic;
	do: OUT std_logic_VECTOR(15 downto 0));
end component;

	signal slot: integer range 0 to 4;
	type stack is array(31 downto 0) of std_logic_vector(width downto 0);
	signal as_stack,ar_stack: stack;
	signal sp,sp1,rp,rp1: integer range 0 to 31; 
	signal at,s,i,p,sum: std_logic_vector(width downto 0);
	signal a,r: std_logic_vector(width downto 0);
	signal t_in,s_in,r_in,a_in,p_in: std_logic_vector(width downto 0);
	signal skip_sel: std_logic_vector(5 downto 0);
	signal code: std_logic_vector(4 downto 0);
	signal t_sel: std_logic_vector(3 downto 0);
	signal p_sel: std_logic_vector(1 downto 0);	
	signal a_sel: std_logic_vector(2 downto 0);
	signal r_sel: std_logic;
	signal spush,spopp,rpush,rpopp,
		tload,aload,pload,iload,reset,z,addr_sel: std_logic;
	signal write,uload: std_logic;
	signal clk0,clr: std_logic;
	signal addr: std_logic_vector(11 downto 0);
	signal data_out,data_in: std_logic_vector(15 downto 0);
	
-- machine instructions selected by code
	constant jmp : std_logic_vector(4 downto 0) :="00000";
	constant ret : std_logic_vector(4 downto 0) :="00001";
	constant bz  : std_logic_vector(4 downto 0) :="00010";
	constant bnc : std_logic_vector(4 downto 0) :="00011";
	constant call: std_logic_vector(4 downto 0) :="00100";
	constant ldp : std_logic_vector(4 downto 0) :="01001";
	constant lit : std_logic_vector(4 downto 0) :="01010";
	constant ld  : std_logic_vector(4 downto 0) :="01011";
	constant stp : std_logic_vector(4 downto 0) :="01101";
	constant st  : std_logic_vector(4 downto 0) :="01111";
	constant com : std_logic_vector(4 downto 0) :="10000";
	constant shl : std_logic_vector(4 downto 0) :="10001";
	constant shr : std_logic_vector(4 downto 0) :="10010";
	constant addc: std_logic_vector(4 downto 0) :="10011";
	constant xorr: std_logic_vector(4 downto 0) :="10100";
	constant andd: std_logic_vector(4 downto 0) :="10101";
	constant addd: std_logic_vector(4 downto 0) :="10111";
	constant pop : std_logic_vector(4 downto 0) :="11000";
	constant lda : std_logic_vector(4 downto 0) :="11001";
	constant dup : std_logic_vector(4 downto 0) :="11010";
	constant push: std_logic_vector(4 downto 0) :="11100";
	constant sta : std_logic_vector(4 downto 0) :="11101";
	constant nop : std_logic_vector(4 downto 0) :="11110";
	constant drop: std_logic_vector(4 downto 0) :="11111";

-- mux to t register, selected by t_sel
	constant not_t: std_logic_vector :="0000";
	constant s_xor_t: std_logic_vector :="0001";
	constant s_and_t: std_logic_vector :="0010";
	constant s_or_t: std_logic_vector :="0011";
	constant sum_t: std_logic_vector :="0100";
	constant shr_sum_t: std_logic_vector :="0101";
	constant shr_t: std_logic_vector :="0110";
	constant shr_t_t: std_logic_vector :="0111";
	constant shl_sum_a_t: std_logic_vector :="1000";
	constant shl_t_a_t: std_logic_vector :="1001";
	constant shl_t: std_logic_vector :="1010";
	constant s_t: std_logic_vector :="1011";
	constant a_t: std_logic_vector :="1100";
	constant r_t: std_logic_vector :="1101";
	constant data_t: std_logic_vector :="1110";

-- mux to a register, selected by a_sel
	constant t_a: std_logic_vector :="000";
	constant a1_a: std_logic_vector :="001";
	constant shr_sum_a: std_logic_vector :="010";
	constant shr_t_a: std_logic_vector :="011";
	constant shl_sum_a: std_logic_vector :="100";

-- mux to r register, selected by r_sel
	constant t_r: std_logic :='0';
	constant p_r: std_logic :='1';

-- mux to p register, selected by p_sel
	constant p1_p: std_logic_vector :="00";
	constant pi_p: std_logic_vector :="01";
	constant r_p: std_logic_vector :="10";
	constant int_p: std_logic_vector :="11";

-- mux to memory bus, selected by addr_sel
	constant p_addr: std_logic :='0';
	constant a_addr: std_logic :='1';

begin
-- concurent assignments, mostly with muxes

	auload<=uload;
	address <= addr;
	clk0 <= not clk;
	clr <= not arst;
	holdosc0 <= arst;	
	r <= ar_stack(rp);
	s <= as_stack(sp);
	data <= data_out;
	data_in <= at(15 downto 0);

------------- Begin Cut here for INSTANTIATION Template ----- INST_TAG
	memory : p16ram
		port map (
			addr => addr,
			clk => clk0,
			di => data_in,
			we => write,
			en => arst,
			rst => clr,
			do => data_out);
-- INST_TAG_END ------ End INSTANTIATION Template ------------

	icode <= code;

	sum <= (('0'&at(width-1 downto 0)) + ('0'&s(width-1 downto 0)));

	with t_sel select
	t_in <= (not at) when not_t,
		(at xor s) when s_xor_t,
		(at and s) when s_and_t,
		sum when sum_t,
		(at(width-1 downto 0) & '0') when shl_t,
		(at(width-1 downto 0) & a(width-1)) when shl_t_a_t,
		(sum(width-1 downto 0) & a(width-1)) when shl_sum_a_t,
		('0'&sum(width downto 1)) when shr_sum_t,
		(uart_in&at(width-1)&at(width-1 downto 1)) when shr_t,
		("00"&at(width-1 downto 1)) when shr_t_t,
		s when s_t,
		a when a_t,
		r when r_t,
		'0'&data_out(width-1 downto 0) when others;

	with slot select
	code <= i(15 downto 11) when 1,
		i(10 downto 6) when 2,
		i(5 downto 1) when 3,
		nop when others;

	a_in <= a+1 when a_sel=a1_a else
		('0'&at(0)&a(width-1 downto 1)) when a_sel=shr_t_a else
		('0'&sum(0)&a(width-1 downto 1)) when a_sel=shr_sum_a else
		('0'&a(width-2 downto 0)&sum(width)) when a_sel=shl_sum_a else
		at ;

	r_in <= p when r_sel=p_r else
		at ;

	p_in <= (p(width downto 11) & i(10 downto 0)) when p_sel=pi_p else
		r when p_sel=r_p else
		("000000000000"&interrupt(4 downto 0)) when p_sel=int_p else
		p+1;

	addr <= a(11 downto 0) when addr_sel=a_addr else
		p(11 downto 0);


	z <= not(at(15) or at(14) or at(13) or at(12)
		or at(11) or at(10) or at(9) or at(8)
		or at(7) or at(6) or at(5) or at(4)
		or at(3) or at(2) or at(1) or at(0));

-- sequential assignments, with slot and code		
	decode: process(code,z,a,at,slot,sum,p,i,interrupt,
			sp,sp1,rp,rp1) begin
		t_sel<="0000"; 
		a_sel<="000";
		p_sel<="00";
		r_sel<='0';
		spush<='0'; 
		spopp<='0';
		rpush<='0'; 
		rpopp<='0'; 
		tload<='0'; 
		aload<='0';
		pload<='0'; 
		addr_sel<='0'; 
		write<='0'; 
		iload<='0';
		reset<='0';
		uload<='0';

	if slot=0 then
--		if interrupt/="00000" then
--			pload<='1';
--			p_sel<=int_p;--process interrupts
--			rpush<='1'; 
--			r_sel<=p_r;
--			reset<='1';
--		else	
			iload<='1';
			p_sel<=p1_p;--fetch next word
			pload<='1';
--		end if;
	else
	case code is
		when jmp =>
			pload<='1';
			p_sel<=pi_p;
			reset<='1';
		when ret => pload<='1'; 
			p_sel<=r_p;
			rpopp<='1';
			reset<='1';
		when bz => 
			if Z='1' then
				pload<='1';
				p_sel<=pi_p;
			end if;
			reset<='1';
		when bnc => 
			if at(width)='0' then
				pload<='1';
				p_sel<=pi_p;
			end if;
			reset<='1';
		when call => 
			pload<='1';
			p_sel<=pi_p;--process call
			rpush<='1'; 
			r_sel<=p_r;
			reset<='1';
		when ldp => addr_sel<=a_addr; 
			a_sel<=a1_a;
			aload<='1'; 
			tload<='1';
			t_sel<=data_t; 
			spush<='1'; 
		when lit => pload<='1'; 
			p_sel<=p1_p;
			tload<='1';
			t_sel<=data_t; 
			spush<='1'; 
		when ld => addr_sel<=a_addr; 
			tload<='1';
			t_sel<=data_t; 
			spush<='1'; 
		when stp => addr_sel<=a_addr; 
			aload<='1'; 
			a_sel<=a1_a;
			tload<='1';
			t_sel<=s_t; 
			spopp<='1'; 
			write<='1'; 
		when st => addr_sel<=a_addr; 
			tload<='1';
			t_sel<=s_t; 
			spopp<='1'; 
			write<='1'; 
		when com => 
			tload<='1';
			t_sel<=not_t; 
		when shl => 
			tload<='1';
			t_sel<=shl_t; 
		when shr => 
			tload<='1';
			t_sel<=shr_t; 
			uload<='1';
		when addc => 
			if at(0)='1' then
				t_sel<=sum_t;
				tload<='1';
			end if;
		when xorr => 
			tload<='1';
			t_sel<=s_xor_t; 
			spopp<='1';
		when andd => 
			tload<='1';
			t_sel<=s_and_t; 
			spopp<='1';
		when addd => 
			tload<='1';
			t_sel<=sum_t; 
			spopp<='1';
		when pop => 
			tload<='1';
			t_sel<=r_t; 
			spush<='1';
			rpopp<='1';
		when lda => 
			tload<='1';
			t_sel<=a_t; 
			spush<='1';
		when dup => 
			spush<='1';
		when push => 
			tload<='1';
			t_sel<=s_t; 
			rpush<='1';
			r_sel<=t_r;
			spopp<='1';
		when sta => 
			tload<='1';
			t_sel<=s_t; 
			a_sel<=t_a;
			aload<='1'; 
			spopp<='1';
		when nop => reset<='1';
		when drop => 
			tload<='1';
			t_sel<=s_t; 
			spopp<='1';
		when others => reset<='1';
	end case;
	end if;
	end process decode;

-- finite state machine, processor control unit	
	sync: process(clk,clr) begin
		if clr='1' then -- master reset
			slot <= 0;
			sp  <= 0;
			sp1 <= 1;
			rp  <= 0;
			rp1 <= 1;
			at <= (others => '0');
			a <= (others => '0');
			p <= (others => '0');
			i <= (others => '0');
			for ii in as_stack'range loop
				as_stack(ii) <= (others => '0');
				ar_stack(ii) <= (others => '0');
			end loop;
		elsif (clk'event and clk='1') then
			if reset='1' or slot=4 then
				slot <= 0;
			else	slot <= slot+1;
			end if;
			if iload='1' then
				i <= '0'&data_out(width-1 downto 0);
			end if;
			if pload='1' then
				p <= p_in;
			end if;
			if tload='1' then
				at <= t_in;
			end if;
			if aload='1' then
				a <= a_in;
			end if;
			if spush='1' then
				as_stack(sp1) <= at;
				sp <= sp+1;
				sp1 <= sp1+1;
			elsif spopp='1' then
				sp <= sp-1;
				sp1 <= sp1-1;
			end if;
			if rpush='1' then
				ar_stack(rp1) <= r_in;
				rp <= rp+1;
				rp1 <= rp1+1;
			elsif rpopp='1' then
				rp <= rp-1;
				rp1 <= rp1-1;
			end if;
			if uload='1' then
				uart_out<=at(0);
			end if;
		end if;
	end process sync;

end archcpu16;



