$TITLE(8051 eForth 2.02)

$PAGEWIDTH(80)
$LIST
$MOD51
$SYMBOLS

;===============================================================
;
;       8051 eForth 2.1, 02/18/98 C. H. Ting
;1.     The Forth virtualmachine is really too cumbersome. Next has
;       more than 20 instructions, making it very slow.
;2.     Subroutine threading seems to be a good way to eliminate the
;       traditaional Forth virtual engine.
;3.     eForth 1.2 uses external RAM for the stacks.  the 128 bytes of
;       the internal memory are quite sufficient for two stacks.
;4.     The hardware return stack SP will be used for Forth return stack.
;       R0 will be used for data stack.  Both pointers are 1 byte wide,
;       and easier to manipulate.
;5.     Code word will have lists of machine code.
;       Colon words will have lists of LCALL statements, same instructure
;       as code words.
;6.     Next will be simply RET.  DOLIST and EXIT are not necessary.
;       Return address on the return stack must be popped to DPTR before
;       other items can be accessed.
;7.     Code space and external RAM space must be the same by AND'ing
;       /RD and /PSEN enable signals to the external RAM and ROM memories.
;       MOV @R0,src and MOV dest,@R0 are used to address data stack.
;       POP, PUSH, and SP are used to address return stack.
;       Code and memory space are addressed using DPTR or MOVX instructions.
;8.     Use register bank 0 for registers.
;       R0      data stack pointer
;       R1      scratch
;       R2      LSB of top of data stack TPL
;       R3      MSB of top of data stack TPH
;       R4      scratch
;       R5      scratch
;       R6      scratch
;       R7      scratch
;9.     Use MetaLink's ASM51 to assemble the 8051 code.  Ready for
;       enhancements.
;10.    Use SIM8031 to simulate the system.  Runs properly to ACCEPT.
;       2/23/98 cht
;11.    Working now.  Excellent benchmarks.  2/26/98 cht
;2.02a  25aug98cht, add READ, OK, and SEND. 9600 baud. Correct SEE.
;2.02b  READ and OK use array parameters.
;2.02c  27aug98cht, fix $" and ABORT".
;2.02d  01sep98cht, improve FIND.
;2.02e  15oct98cht, patch C, in ROM at 151AH.
;
;       Subroutine threaded eForth; Version. 2.0, 1991
;       for the Motorola M68HC11EVB Evaluation Board 
;       by Richard E. Haskell
;               Dept. of Computer Science and Engineering
;               Oakland University
;               Rochester, Michigan 48309
;       based on
;       eForth 1.0 by Bill Muench and C. H. Ting, 1990
;       Much of the code is derived from the following sources:
;               8086 figForth by Thomas Newman, 1981 and Joe smith, 1983
;               aFORTH by John Rible
;               bFORTH by Bill Muench
;
;       The goal of this implementation is to provide a simple eForth Model
;       which can be ported easily to many 8, 16, 24 and 32 bit CPU's.
;       The following attributes make it suitable for CPU's of the '90:
;
;               small machine dependent kernel and portable high level code
;               source code in the MASM format
;               subroutine threaded code
;               separated code and name dictionaries
;               simple vectored terminal and file interface to host computer
;               aligned with the proposed ANS Forth Standard
;               easy upgrade path to optimize for specific CPU
;               easy mixing of Forth and assembly language
;               all assembly language tools can be used directly
;
;       You are invited to implement this Model on your favorite CPU and
;       contribute it to the eForth Library for public use. You may use
;       a portable implementation to advertise more sophisticated and
;       optimized version for commercial purposes. However, you are
;       expected to implement the Model faithfully. The eForth Working
;       Group reserves the right to reject implementation which deviates
;       significantly from this Model.
;
;       As the ANS Forth Standard is still evolving, this Model will
;       change accordingly. Implementations must state clearly the
;       version number of the Model being tracked.
;
;       Representing the eForth Working Group in the Silicon Valley FIG Chapter.
;       Send contributions to:
;
;               Dr. C. H. Ting
;               156 14th Avenue
;               San Mateo, CA 94402
;               (415) 571-7639
;
;===============================================================

;; Version control

VER             EQU     2       ;major release version
EXT     EQU     2       ;minor extension

;; Constants

TRUEE           EQU     0FFFFH  ;true flag

;       lexicon bits -- Motorola format -- flip for Intel
COMPO           EQU     040H    ;lexicon compile only bit
IMEDD           EQU     080H    ;lexicon immediate bit
MASKK   EQU     07F1FH  ;lexicon bit mask
        
CELLL           EQU     2       ;size of a cell
BASEE           EQU     10      ;default radix
VOCSS           EQU     8       ;depth of vocabulary stack

BKSPP           EQU     8       ;back space
LF              EQU     10      ;line feed
CRR             EQU     13      ;carriage return
ERR             EQU     27      ;error escape
TIC             EQU     39      ;tick

;               Change these opcodes for your own microprocessor.
CALLL   EQU     12H     ; LCALL opcode
RETT    EQU     22H     ; RET opcode

;; Memory allocation    CHANGE FOR DIFFERENT ENVIRONMENTS
BM      EQU     0       ;bottom of ROM memory
RAM     EQU     08100H  ;start of RAM
EM      EQU     0A000H  ;top of RAM memory
US      EQU     128*CELLL        ;user area size in cells
RTS     EQU     128*CELLL        ;TIB size, towards infinity

TIBB    EQU     8080H   ;terminal input buffer (TIB)
UPP     EQU     8000H   ;start of user area (UP0)
RPP     EQU     10H     ;start of return stack (RP0)
SPP     EQU     50H     ;start of data stack (SP0)

COLDD   EQU     0000H   ;cold start vector
CODEE   EQU     COLDD+100H      ;code dictionary

;; Initialize assembly variables

_LINK   SET     0       ;force a null link
_USER   SET     4*CELLL ;first user variable offset
_NAME   SET     RAM

SPL     EQU     0        ;R0
UPH     EQU     1        ;R1
TPL     EQU     2        ;R2
TPH     EQU     3        ;R3

;; Define assembly macros
;       These must be changed for different microprocessors.

;       Define a word  (Intel order)
?DW     MACRO   WORD1
        DW      (WORD1 SHR 8) + ((WORD1 AND 255) SHL 8)
        ENDM

;       Define the words IMEDD and COMPO  (Intel order)
?DWLEX  MACRO   WORD1
                DB      WORD1   
                DB      0
        ENDM

;       Define the constant -1
?DCM1   MACRO   WORD1
                DW      WORD1
        ENDM

;       Define a negative constant 
?DWNEG  MACRO   BYTE1
                DB      0FFH
                DB      BYTE1
        ENDM

;       Compile a subroutine call
?CALL   MACRO   WORD1
        LCALL   WORD1
        ENDM

;       Compile a subroutine return
?RET    MACRO   
        RET
        ENDM

;;      The following should not have to be changed
;       Compile a code definition header.

ALIGN   MACRO
        IF ($ AND 1)
        DB      0
        ENDIF
        ENDM

?CODE   MACRO   LEX,NAME,LABEL
        ALIGN
;       ?DW     LABEL   ;;token pointer
        ?DW     _LINK   ;;link pointer
_LINK   SET     $       ;;link points to a name string
        DB      LEX,NAME        ;;name string
        ALIGN
LABEL:   ;;assembly label
        ENDM

;       Compile a colon definition header.

?COLON  MACRO   LEX,NAME,LABEL
        ?CODE   LEX,NAME,LABEL
        ENDM

;       Compile a user variable header.

?USER   MACRO   LEX,NAME,LABEL
        ?CODE   LEX,NAME,LABEL
        ?CALL   DOUSE   ;;followed by doUSER
        ?DW     _USER   ;; and offset
_USER   SET     _USER+CELLL     ;;update user area offset
        ENDM

;       CHANGE THE FOLLOWING MACHINE DEPENDENT WORDS
;; Main entry points and COLD start data


        ORG     BM       ;Power up location******

        DB      02H,1,0 ;Jump to cold start
        DB      32H,0,0,0,0,0,0,0       ;Return from interrupt
        DB      32H,0,0,0,0,0,0,0       ;Return from interrupt
        DB      32H,0,0,0,0,0,0,0       ;Return from interrupt
        DB      32H,0,0,0,0,0,0,0       ;Return from interrupt
        DB      32H,0,0,0,0,0,0,0       ;Return from interrupt
        DB      32H,0,0,0,0,0,0,0       ;Return from interrupt
        DB      32H,0,0,0,0,0,0,0       ;Return from interrupt
        DB      32H,0,0,0,0

;       ORG     COLDD   ;beginning of cold boot area

; COLD start moves the following to USER variables.
; MUST BE IN SAME ORDER AS USER VARIABLES.

UZERO:  ?DW     0       ;reserved space in user area
        ?DW     0
        ?DW     0
        ?DW     0
        ?DW     SPP     ;SP0
        ?DW     RPP     ;RP0
        ?DW     QRX     ;'?KEY
        ?DW     TXSTO   ;'EMIT
        ?DW     ACCEP   ;'EXPECT
        ?DW     KTAP    ;'TAP
        ?DW     TXSTO   ;'ECHO
        ?DW     DOTOK   ;'PROMPT
        ?DW     BASEE   ;BASE
        ?DW     0       ;tmp
        ?DW     0       ;SPAN
        ?DW     0       ;>IN
        ?DW     0       ;#TIB
        ?DW     TIBB    ;TIB
        ?DW     0       ;CSP
        ?DW     INTER   ;'EVAL
        ?DW     NUMBQ   ;'NUMBER
        ?DW     0       ;HLD
        ?DW     0       ;HANDLER
        ?DW     0       ;CONTEXT pointer
;       DS      VOCSS ;UP (0)   ;vocabulary stack
        ?DW     0
        ?DW     0
        ?DW     0
        ?DW     0
        ?DW     0
        ?DW     0
        ?DW     0
        ?DW     0
        ?DW     0       ;CURRENT pointer
        ?DW     0       ;vocabulary link pointer
        ?DW     CTOP    ;CP
        ?DW     NTOP    ;NP
        ?DW     LASTN   ;LAST
        ?DW     LASTN   ;FORTH vocabulary
        ?DW     0       ;vocabulary link
        ?DW     0
ULAST:
_ULMUZ SET ULAST-UZERO

        ORG     CODEE   ;start code dictionary

ORIG:   ;Cold boot routine

        CLR     A
        MOV     PSW,A   ;use bank 0
        MOV     IE,A
        MOV     P2,A
        MOV     SP,#10H ;return stack
        MOV     R0,#20H ;data stack
        MOV     R1,#(UPP/256)   ;user area pointer
        MOV     TH1,#0FAH
        MOV     PCON,#80H
        MOV     SCON,#50H
        SETB    TCON.6
        MOV     TMOD,#20H
COPY:   MOV     R2,#20H
        MOV     R3,A
        MOV     DPTR,#0
COPY1:  CLR     A
        MOVC    A,@A+DPTR
        MOVX    @DPTR,A
        INC     DPTR
        DJNZ    R3,COPY1        ;to get simulator to run properly,
        DJNZ    R2,COPY1        ;copy 2000H byte of code to data memory
        LJMP    COLD1
        
;; Device dependent I/O

;       !IO             ( -- )
;               Initialize the serial I/O devices.

        ?CODE   3,'!IO',STOIO
        CLR     IE.4
        MOV     SCON,#52H
        RET

;       ?RX             ( -- c T | F )
;               Return input character and true, or a false if no input.

        ?CODE   3,'?RX',QRX
        INC     R0
        MOV     @R0,TPL
        INC     R0
        MOV     @R0,TPH
QRX0:   JNB     SCON.0,QRX1
        CLR     SCON.0
        INC     R0
        MOV     @R0,SBUF
        INC     R0
        MOV     @R0,#0
        MOV     A,#0FFH
        SJMP    QRX2
QRX1:   CLR     A
QRX2:   MOV     R2,A
        MOV     R3,A
        RET

;       TX!             ( c -- )
;               Send character c to the output device.

        ?CODE   3,'TX!',TXSTO
        JNB     SCON.1,TXTS1
        CLR     SCON.1
TXTS1:  MOV     SBUF,R2
TXTS2:  JNB     SCON.1,TXTS2
        CLR     SCON.1
        MOV     TPH,@R0
        DEC     R0
        MOV     TPL,@R0
        DEC     R0
        RET

;; The kernel

;       doLIT   ( -- w )
;               Push an inline literal.

        ?CODE   COMPO+5,'doLIT',DOLIT
        POP     DPH     ;need return address for literal
        POP     DPL
        INC     R0      ;push tos
        MOV     @R0,TPL
        INC     R0
        MOV     @R0,TPH
        MOVX    A,@DPTR  ;get literal
        MOV     R2,A
        INC     DPTR
        MOVX    A,@DPTR
        MOV     R3,A
        MOV     A,#1    ;return address is now DPTR+1
        JMP     @A+DPTR

;       next    ( -- )
;               Run time code for the single index loop.
;               : next ( -- ) \ hilevel model
;       r> r> dup if 1 - >r @ >r exit then drop cell+ >r ;

        ?CODE   COMPO+4,'next',DONXT
        POP     DPH     ;save return address
        POP     DPL
        POP     B        ;get msb of count
        POP     ACC     ;get lsb of count
        CLR     C
        SUBB    A,#1    ;decrement count
        PUSH    ACC     ;push lsb of count
        MOV     A,B     ;process msb in NPL
        SUBB    A,#0
        MOV     B,A     ;save msb back to NPL
        JNC     NEXT1   ;not at end, loop back
        DEC     SP      ;pop lsb of count
        MOV     A,#2
        JMP     @A+DPTR  ;exit loop
NEXT1:  PUSH    B        ;push msb of count
        MOVX    A,@DPTR  ;get loop address
        PUSH    ACC
        INC     DPTR
        MOVX    A,@DPTR
        PUSH    ACC
        RET     ;loop back

;       ?branch ( f -- )
;               Branch if flag is zero.

        ?CODE   COMPO+7,'?branch',QBRAN
        MOV     A,R2
        ORL     A,R3
        MOV     TPH,@R0  ;pop nos
        DEC     R0
        MOV     TPL,@R0
        DEC     R0
        JZ      BRAN    ;f=0, do branch
        POP     DPH     ;f<>0, skip branch address
        POP     DPL
        MOV     A,#2
        JMP     @A+DPTR

;       branch  ( -- )
;               Branch to an inline address.

        ?CODE   COMPO+6,'branch',BRAN
        POP     DPH
        POP     DPL
        MOVX    A,@DPTR  ;get lsb of branch address
        PUSH    ACC
        INC     DPTR
        MOVX    A,@DPTR  ;get msb of branch address
        PUSH    ACC
        RET

;       EXECUTE ( ca -- )
;               Execute the word at ca.

        ?CODE   7,'EXECUTE',EXECU
        PUSH    TPL     ;prepare to jump through RET
        PUSH    TPH
        MOV     TPH,@R0 ;pop nos
        DEC     R0
        MOV     TPL,@R0
        DEC     R0
        RET

;       !               ( w a -- )
;               Pop the data stack to memory.

        ?CODE   1,'!',STORE
        MOV     DPL,R2  ;get address into DPTR
        MOV     DPH,R3
        MOV     TPH,@R0 ;pop msb of data
        DEC     R0
        MOV     A,@R0   ;pop lsb of data
        DEC     R0
        MOVX    @DPTR,A ;store lsb
        INC     DPTR
        MOV     A,R3
        MOVX    @DPTR,A ;store msb
        MOV     TPH,@R0 ;pop nos again
        DEC     R0
        MOV     TPL,@R0
        DEC     R0
        RET

;       @               ( a -- w )
;               Push memory location to the data stack.

        ?CODE   1,'@',ATT
        MOV     DPL,R2  ;get address into DPTR
        MOV     DPH,R3
        MOVX    A,@DPTR ;get lsb
        MOV     R2,A    ;store in tos
        INC     DPTR
        MOVX    A,@DPTR ;get msb
        MOV     R3,A    ;store in tos
        RET

;       C!              ( c b -- )
;               Pop the data stack to byte memory.

        ?CODE   2,'C!',CSTOR
        MOV     DPL,R2  ;get address
        MOV     DPH,R3
        DEC     R0
        MOV     A,@R0   ;need only lsb
        DEC     R0
        MOVX    @DPTR,A ;store lsb
        MOV     TPH,@R0 ;pop nos again
        DEC     R0
        MOV     TPL,@R0
        DEC     R0
        RET

;       C@              ( b -- c )
;               Push byte memory location to the data stack.

        ?CODE   2,'C@',CAT
        MOV     DPL,R2  ;get address
        MOV     DPH,R3
        MOVX    A,@DPTR  ;get lsb
        MOV     R2,A
        MOV     R3,#0   ;clear msb
        RET

;       >R              ( w -- )
;               Push the data stack to the return stack.

        ?CODE   COMPO+2,'>R',TOR
        POP     DPH     ;save return address
        POP     DPL
        PUSH    TPL     ;push tos on return stack
        PUSH    TPH
        MOV     TPH,@R0 ;pop nos
        DEC     R0
        MOV     TPL,@R0
        DEC     R0
        CLR     A       ;return via DPTR
        JMP     @A+DPTR

;       R@              ( -- w )
;               Copy top of return stack to the data stack.

        ?CODE   2,'R@',RAT
        INC     R0       ;push tos
        MOV     @R0,TPL
        INC     R0
        MOV     @R0,TPH
        MOV     A,SP    ;save return stack pointer
        DEC     SP
        DEC     SP
        POP     TPH     ;copy top of return stack
        POP     TPL
        MOV     SP,A    ;restore return stack
        RET

;       R>              ( -- w )
;               Pop the return stack to the data stack.

        ?CODE   2,'R>',RFROM
        INC     R0      ;push tos
        MOV     @R0,TPL
        INC     R0
        MOV     @R0,TPH
        POP     DPH     ;save return address
        POP     DPL
        POP     TPH     ;pop return stack to tos
        POP     TPL
        CLR     A        ;return via DPTR
        JMP     @A+DPTR

;       RP@             ( -- a )
;               Push the current RP to the data stack.

        ?CODE   3,'RP@',RPAT
        INC     R0      ;push tos
        MOV     @R0,TPL
        INC     R0
        MOV     @R0,TPH
        MOV     R2,SP   ;new return stack pointer
        DEC     R2       ;old return stack pointer
        DEC     R2
        MOV     R3,#0   ;clear msb
        RET

;       RP!             ( a -- )
;               Set the return stack pointer.

        ?CODE   COMPO+3,'RP!',RPSTO
        POP     DPH     ;pop return address
        POP     DPL
        MOV     SP,R2   ;set RP pointer
        MOV     TPH,@R0 ;pop nos
        DEC     R0
        MOV     TPL,@R0
        DEC     R0
        CLR     A
        JMP     @A+DPTR ;return via DPTR

;       SP@             ( -- a )
;               Push the current data stack pointer.

        ?CODE   3,'SP@',SPAT
        INC     R0      ;push tos
        MOV     @R0,TPL
        INC     R0
        MOV     @R0,TPH
        MOV     TPL,R0  ;copy SP pointer to tos
        MOV     R3,#0
        RET

;       SP!             ( a -- )
;               Set the data stack pointer.

        ?CODE   3,'SP!',SPSTO
        MOV     R0,TPL  ;install new SP pointer
        MOV     TPH,@R0  ;get what should be in tos
        DEC     R0
        MOV     TPL,@R0
        DEC     R0
        RET

;       DUP             ( w -- w w )

        ?CODE   3,'DUP',DUPP
        INC     R0      ;push tos
        MOV     @R0,TPL
        INC     R0
        MOV     @R0,TPH
        RET

;       ?DUP    ( w -- w w | 0 )
;               Dup tos if its is not zero.

        ?CODE   4,'?DUP',QDUP
        MOV     A,R2
        ORL     A,R3
        JNZ     DUPP
        RET

;       DROP    ( w -- )
;               Discard top stack item.

        ?CODE   4,'DROP',DROP
        MOV     TPH,@R0 ;pop nos
        DEC     R0
        MOV     TPL,@R0
        DEC     R0
        RET

;       SWAP    ( w1 w2 -- w2 w1 )
;               Exchange top two stack items.

        ?CODE   4,'SWAP',SWAPP
        MOV     A,R3    ;exchange msb
        XCH     A,@R0
        MOV     R3,A
        DEC     R0
        MOV     A,R2    ;exchange lsb
        XCH     A,@R0
        MOV     R2,A
        INC     R0
        RET

;       OVER    ( w1 w2 -- w1 w2 w1 )
;               Copy second stack item to top.

        ?CODE   4,'OVER',OVER
        MOV     B,@R0   ;get w1
        DEC     R0
        MOV     A,@R0
        INC     R0
        INC     R0      ;push tos
        MOV     @R0,TPL
        INC     R0
        MOV     @R0,TPH
        MOV     R3,B    ;copy w1 to tos
        MOV     R2,A
        RET

;       0<              ( n -- t )
;               Return true if n is negative.

        ?CODE   2,'0<',ZLESS
        MOV     A,R3
        JNB     ACC.7,ZLESS1
        MOV     A,#0FFH
        SJMP    ZLESS2
ZLESS1: CLR     A
ZLESS2: MOV     R2,A
        MOV     R3,A
        RET

;       AND             ( w w -- w )
;               Bitwise AND.

        ?CODE   3,'AND',ANDD
        MOV     A,@R0
        ANL     TPH,A
        DEC     R0
        MOV     A,@R0
        ANL     TPL,A
        DEC     R0
        RET

;       OR              ( w w -- w )
;               Bitwise inclusive OR.

        ?CODE   2,'OR',ORR
        MOV     A,@R0
        ORL     TPH,A
        DEC     R0
        MOV     A,@R0
        ORL     TPL,A
        DEC     R0
        RET

;       XOR             ( w w -- w )
;               Bitwise exclusive OR.

         ?CODE  3,'XOR',XORR
        MOV     A,@R0
        XRL     TPH,A
        DEC     R0
        MOV     A,@R0
        XRL     TPL,A
        DEC     R0
        RET

;       UM+             ( w w -- w cy )
;               Add two numbers, return the sum and carry flag.

        ?CODE   3,'UM+',UPLUS
        DEC     R0      ;add lsb
        MOV     A,R2
        ADD     A,@R0
        MOV     @R0,A
        INC     R0      ;add msb
        MOV     A,R3
        ADDC    A,@R0
        MOV     @R0,A
        CLR     A        ;store carry
        MOV     R3,A
        ADDC    A,R3
        MOV     R2,A
        RET

;       ROT             ( w1 w2 w3 -- w2 w3 w1 )
;               Rot 3rd item to top.

        ?CODE   3,'ROT',ROT
        MOV     B,R0
        MOV     A,R3
        XCH     A,@R0
        DEC     R0
        DEC     R0
        XCH     A,@R0
        MOV     R3,A
        INC     R0
        MOV     A,R2
        XCH     A,@R0
        DEC     R0
        DEC     R0
        XCH     A,@R0
        MOV     R2,A
        MOV     R0,B
        RET

;       2DROP   ( w w -- )
;               Discard two items on stack.

        ?CODE   5,'2DROP',DDROP
        DEC     R0
        DEC     R0
        MOV     TPH,@R0
        DEC     R0
        MOV     TPL,@R0
        DEC     R0
        RET

;       2DUP    ( w1 w2 -- w1 w2 w1 w2 )
;               Duplicate top two items.

        ?CODE   4,'2DUP',DDUP
        DEC     R0
        MOV     A,@R0
        INC     R0
        MOV     B,@R0
        INC     R0
        MOV     @R0,TPL
        INC     R0
        MOV     @R0,TPH
        INC     R0
        MOV     @R0,A
        INC     R0
        MOV     @R0,B
        RET

;       +        ( n n -- n  )
;        Add two numbers, return the sum.

        ?CODE   1,'+',PLUS
        MOV     B,@R0   ;save msb
        DEC     R0
        MOV     A,R2
        ADD     A,@R0   ;add lsb
        MOV     R2,A
        MOV     A,R3
        ADDC    A,B     ;add msb
        MOV     R3,A
        DEC     R0
        RET

;       -        ( n n -- n  )
;        Add two numbers, return the sum.

        ?CODE   1,'-',SUBBB
        CLR     C
        MOV     B,@R0   ;save msb
        DEC     R0
        MOV     A,@R0
        DEC     R0
        SUBB    A,R2    ;subtract lsb
        MOV     R2,A
        MOV     A,B
        SUBB    A,R3    ;subtract msb
        MOV     R3,A
        RET

;       NOT             ( w -- w )
;               One's complement of tos.

        ?CODE   3,'NOT',INVER
        MOV     A,R2
        CPL     A
        MOV     R2,A
        MOV     A,R3
        CPL     A
        MOV     R3,A
        RET

;       NEGATE  ( n -- -n )
;               Two's complement of tos.

        ?CODE   6,'NEGATE',NEGAT
        CLR     A
        CLR     C
        SUBB    A,R2
        MOV     R2,A
        CLR     A
        SUBB    A,R3
        MOV     R3,A
        RET

;       ABS             ( n -- n )
;               Return the absolute value of n.

        ?CODE   3,'ABS',ABSS
        MOV     A,R3
        JB      ACC.7,NEGAT
        RET

;       FLIP    ( n -- n )
;        Exchange upper and lower bytes of tos.

        ?CODE   4,'FLIP',FLIP
        MOV     A,R2
        XCH     A,R3
        MOV     R2,A
        RET

;       DNEGATE ( d -- -d )
;               Two's complement of top double.

        ?CODE   7,'DNEGATE',DNEGA
        CLR     A
        CLR     C
        DEC     R0
        SUBB    A,@R0
        MOV     @R0,A
        INC     R0
        CLR     A
        SUBB    A,@R0
        MOV     @R0,A
        CLR     A
        SUBB    A,R2
        MOV     R2,A
        CLR     A
        SUBB    A,R3
        MOV     R3,A
        RET

;       =               ( w w -- t )
;               Return true if top two are equal.

        ?CODE   1,'=',EQUAL
        MOV     A,@R0
        XRL     TPH,A
        DEC     R0
        MOV     A,@R0
        XRL     TPL,A
        DEC     R0
        MOV     A,R2
        ORL     A,R3
        JZ      EQU1
        CLR     A
        SJMP    EQU2
EQU1:   MOV     A,#0FFH
EQU2:   MOV     R2,A
        MOV     R3,A
        RET

;       U<              ( u u -- t )
;               Unsigned compare of top two items.

        ?CODE   2,'U<',ULESS
        CLR     C
        MOV     B,@R0
        DEC     R0
        MOV     A,@R0
        SUBB    A,R2
        DEC     R0
        MOV     A,B
        SUBB    A,R3
        JC      EQU1
        CLR     A
        SJMP    EQU2

;       CELL+   ( a -- a )
;               Add cell size in byte to address.

        ?CODE   5,'CELL+',CELLP
        MOV     A,#2
        ADD     A,R2
        MOV     R2,A
        JNC     CELLP1
        INC     R3
CELLP1: RET

;       CELL-   ( a -- a )
;               Subtract cell size in byte from address.

        ?CODE   5,'CELL-',CELLM
        CLR     C
        MOV     A,R2
        SUBB    A,#2
        MOV     R2,A
        JNC     CELLM1
        DEC     R3
CELLM1: RET

;       CELLS   ( n -- n )
;               Multiply tos by cell size in bytes.

        ?CODE   5,'CELLS',CELLS
        MOV     A,R2
        CLR     C
        RLC     A
        MOV     R2,A
        MOV     A,R3
        RLC     A
        MOV     R3,A
        RET

;       1+      ( a -- a+1 )
;        Add 1 to address.

        ?CODE   2,'1+',ONEP
        MOV     A,#1
        ADD     A,R2
        MOV     R2,A
        JNC     ONEP1
        INC     R3
ONEP1:  RET

;       1-      ( a -- a-1 )
;        Subtract 1 from address.

        ?CODE  2,'1-',ONEM
        CLR     C
        MOV     A,R2
        SUBB    A,#1
        MOV     R2,A
        JNC     ONEM1
        DEC     R3
ONEM1:  RET

;       2/      ( n -- n/2 )
;        Divide tos by 2.

        ?CODE   2,'2/',TWOSL
        CLR     C
        MOV     A,R3
        JNB     ACC.7,TWOSL1
        SETB    C
TWOSL1: RRC     A
        MOV     R3,A
        MOV     A,R2
        RRC     A
        MOV     R2,A
        RET

;       ALIGNED ( b -- a )
;               Align address to the cell boundary.

        ?CODE   7,'ALIGNED',ALGND
        MOV     A,R2
        JNB     ACC.0,ALGN1
        ADD     A,#1
        MOV     R2,A
        JNC     ALGN1
        INC     R3
ALGN1:  RET

;       subtract R2,R3 from R4,R5 and store results in R4,R5
;       if underflow, return with carry set but do not store to R4,R5

DIVSTEP:
        CLR     C
        MOV     A,R6
        SUBB    A,R2
        MOV     @R0,A   ;it is save to use tos
        MOV     A,R7
        SUBB    A,R3
        JC      DVSTP1  ;fail, do not store
        MOV     R7,A
        MOV     6,@R0   ;get back the low byte
DVSTP1:  RET

;       UM/MOD  ( udl udh u -- ur uq)
;       Unsigned divide of a double by a single, return remainder and quotient.

        ?CODE   6,'UM/MOD',UMMOD
        MOV     B,#16
        MOV     7,@R0
        DEC     R0
        MOV     6,@R0
        DEC     R0
        MOV     5,@R0
        DEC     R0
        MOV     4,@R0
        CALL    DIVSTEP
        JC      DIV2    ;divide overflow, return -1
        MOV     A,0FFH
        MOV     @R0,A
        INC     R0
        MOV     @R0,A
        MOV     R2,A
        MOV     R3,A
        RET
DIV1:   CALL    DIVSTEP
DIV2:   CPL     C
        MOV     A,R4
        RLC     A
        MOV     R4,A
        MOV     A,R5
        RLC     A
        MOV     R5,A
        MOV     A,R6
        RLC     A
        MOV     R6,A
        MOV     A,R7
        RLC     A
        MOV     R7,A
        DJNZ    B,DIV1

        CALL    DIVSTEP  ;last step
        CPL     C        ;quotient needs last shift
        MOV     A,R4
        RLC     A
        MOV     R2,A
        MOV     A,R5
        RLC     A
        MOV     R3,A
        MOV     @R0,6   ;remainder is ready
        INC     R0
        MOV     @R0,7
        RET

;       UM*             ( u u -- ud )
;               Unsigned multiply. Return double product.
;        NL NH x R2 R3 = R4 R5 R6 R7

        ?CODE   3,'UM*',UMSTA
        CLR     A        ;clear product registers
        MOV     R6,A
        MOV     R7,A
        DEC     R0      ;get NL
        MOV     A,@R0
        MOV     B,R2
        MUL     AB      ;NLxR2
        MOV     R4,A
        MOV     R5,B
        MOV     A,@R0   ;get NL again
        MOV     B,R3
        MUL     AB      ;NLxR3
        ADD     A,R5
        MOV     R5,A
        MOV     A,B
        ADDC    A,R6    ;R6 is 0
        MOV     R6,A    ;store carry
        MOV     @R0,4   ;store sum0
        INC     R0
        MOV     A,@R0   ;get NH
        MOV     B,R2
        MUL     AB      ;NHxR2
        ADD     A,R5
        MOV     R5,A    ;save sum1
        MOV     A,B
        ADDC    A,R6    ;carry 1
        MOV     R6,A
        CLR     A
        ADDC    A,R7    ;carry 2
        MOV     R7,A
        MOV     A,@R0   ;get NH again
        MOV     B,R3
        MUL     AB      ;NHxR3
        ADD     A,R6
        MOV     R2,A    ;store sum2
        MOV     A,B
        ADDC    A,R7
        MOV     R3,A    ;store sum3
        MOV     @R0,5   ;store sum1
        RET

;; System and user variables

;       doVAR   ( -- a )
;               Run time routine for VARIABLE and CREATE.

        ?CODE   COMPO+5,'doVAR',DOVAR
        INC     R0      ;push tos
        MOV     @R0,TPL
        INC     R0
        MOV     @R0,TPH
        POP     TPH     ;return address is variable address
        POP     TPL
        RET

;       UP              ( -- a )
;               Pointer to the user area.
 
        ?COLON  2,'UP',UP
        ?CALL   DOVAR
        ?DW     UPP

;       doUSER  ( -- a )
;               Run time routine for user variables.

        ?CODE   COMPO+6,'doUSER',DOUSE
        POP     DPH     ;need return address for literal
        POP     DPL
        INC     R0      ;push tos
        MOV     @R0,TPL
        INC     R0
        MOV     @R0,TPH
        MOVX    A,@DPTR  ;get user variable offset
        MOV     R2,A
        MOV     R3,UPH  ;get high byte of user area
        RET

;               ALL THE REST OF THE CODE SHOULD BE INDEPENDENT
;               OF ANY PARTICULAR MICROPROCESSOR!

;       SP0             ( -- a )
;               Pointer to bottom of the data stack.

        ?USER   3,'SP0',SZERO

;       RP0             ( -- a )
;               Pointer to bottom of the return stack.

        ?USER   3,'RP0',RZERO

;       '?KEY   ( -- a )
;               Execution vector of ?KEY.

        ?USER   5,'''?KEY',TQKEY

;       'EMIT   ( -- a )
;               Execution vector of EMIT.

        ?USER   5,'''EMIT',TEMIT

;       'EXPECT ( -- a )
;               Execution vector of EXPECT.

        ?USER   7,'''EXPECT',TEXPE

;       'TAP    ( -- a )
;               Execution vector of TAP.

        ?USER   4,'''TAP',TTAP

;       'ECHO   ( -- a )
;               Execution vector of ECHO.

        ?USER   5,'''ECHO',TECHO

;       'PROMPT ( -- a )
;               Execution vector of PROMPT.

        ?USER   7,'''PROMPT',TPROM

;       BASE    ( -- a )
;               Storage of the radix base for numeric I/O.

        ?USER   4,'BASE',BASE

;       tmp             ( -- a )
;               A temporary storage location used in parse and find.

        ?USER   COMPO+3,'tmp',TEMP

;       SPAN    ( -- a )
;               Hold character count received by EXPECT.

        ?USER   4,'SPAN',SPAN

;       >IN             ( -- a )
;               Hold the character pointer while parsing input stream.

        ?USER   3,'>IN',INN

;       #TIB    ( -- a )
;               Hold the current count in and address of the terminal input buffer.

        ?USER   4,'#TIB',NTIB
        _USER SET _USER+CELLL   ;hold the base address of the terminal input buffer

;       CSP             ( -- a )
;               Hold the stack pointer for error checking.

        ?USER   3,'CSP',CSP

;       'EVAL   ( -- a )
;               Execution vector of EVAL.

        ?USER   5,'''EVAL',TEVAL

;       'NUMBER ( -- a )
;               Execution vector of NUMBER?.

        ?USER   7,'''NUMBER',TNUMB

;       HLD             ( -- a )
;               Hold a pointer in building a numeric output string.

        ?USER   3,'HLD',HLD

;       HANDLER ( -- a )
;               Hold the return stack pointer for error handling.

        ?USER   7,'HANDLER',HANDL

;       CONTEXT ( -- a )
;               A area to specify vocabulary search order.

        ?USER   7,'CONTEXT',CNTXT
        _USER SET _USER+VOCSS*CELLL     ;vocabulary stack

;       CURRENT ( -- a )
;               Point to the vocabulary to be extended.

        ?USER   7,'CURRENT',CRRNT
        _USER SET _USER+CELLL   ;vocabulary link pointer

;       CP              ( -- a )
;               Point to the top of the code dictionary.

        ?USER   2,'CP',CP

;       NP              ( -- a )
;               Point to the bottom of the name dictionary.

        ?USER   2,'NP',NP

;       LAST    ( -- a )
;               Point to the last name in the name dictionary.

        ?USER   4,'LAST',LAST

;       forth   ( -- a )
;               Point to the last name in the name dictionary.

        ?USER   5,'forth',VFRTH

;; Common functions

;       FORTH   ( -- )
;               Make FORTH the context vocabulary.

        ?COLON  5,'FORTH',FORTH
        ?CALL   VFRTH
        ?CALL   CNTXT
        ?CALL   STORE
        ?RET

;       <               ( n1 n2 -- t )
;               Signed compare of top two items.

        ?COLON  1,'<',LESS
        ?CALL   DDUP
        ?CALL   XORR
        ?CALL   ZLESS
        ?CALL   QBRAN
        ?DW     LESS1
        ?CALL   DROP
        ?CALL   ZLESS
        ?RET
LESS1:  ?CALL   SUBBB
        ?CALL   ZLESS
        ?RET

;       MAX             ( n n -- n )
;               Return the greater of two top stack items.

        ?COLON  3,'MAX',MAX
        ?CALL   DDUP
        ?CALL   LESS
        ?CALL   QBRAN
        ?DW     MAX1
        ?CALL   SWAPP
MAX1:   ?CALL   DROP
        ?RET

;       MIN             ( n n -- n )
;               Return the smaller of top two stack items.

        ?COLON  3,'MIN',MIN
        ?CALL   DDUP
        ?CALL   SWAPP
        ?CALL   LESS
        ?CALL   QBRAN
        ?DW     MIN1
        ?CALL   SWAPP
MIN1:   ?CALL   DROP
        ?RET

;       WITHIN  ( u ul uh -- t )
;               Return true if u is within the range of ul and uh. ( ul <= u < uh )

        ?COLON  6,'WITHIN',WITHI
        ?CALL   OVER
        ?CALL   SUBBB
        ?CALL   TOR
        ?CALL   SUBBB
        ?CALL   RFROM
        ?CALL   ULESS
        ?RET

;; Divide

;       M/MOD   ( d n -- r q )
;               Signed floored divide of double by single. Return mod and quotient.

        ?COLON  5,'M/MOD',MSMOD
        ?CALL   DUPP
        ?CALL   ZLESS
        ?CALL   DUPP
        ?CALL   TOR
        ?CALL   QBRAN
        ?DW     MMOD1
        ?CALL   NEGAT
        ?CALL   TOR
        ?CALL   DNEGA
        ?CALL   RFROM
MMOD1:  ?CALL   TOR
        ?CALL   DUPP
        ?CALL   ZLESS
        ?CALL   QBRAN
        ?DW     MMOD2
        ?CALL   RAT
        ?CALL   PLUS
MMOD2:  ?CALL   RFROM
        ?CALL   UMMOD
        ?CALL   RFROM
        ?CALL   QBRAN
        ?DW     MMOD3
        ?CALL   SWAPP
        ?CALL   NEGAT
        ?CALL   SWAPP
MMOD3:  ?RET

;       /MOD    ( n n -- r q )
;               Signed divide. Return mod and quotient.

        ?COLON  4,'/MOD',SLMOD
        ?CALL   OVER
        ?CALL   ZLESS
        ?CALL   SWAPP
        ?CALL   MSMOD
        ?RET

;       MOD             ( n n -- r )
;               Signed divide. Return mod only.

        ?COLON  3,'MOD',MODD
        ?CALL   SLMOD
        ?CALL   DROP
        ?RET

;       /               ( n n -- q )
;               Signed divide. Return quotient only.

        ?COLON  1,'/',SLASH
        ?CALL   SLMOD
        ?CALL   SWAPP
        ?CALL   DROP
        ?RET

;; Multiply

;       *               ( n n -- n )
;               Signed multiply. Return single product.

        ?COLON  1,'*',STAR
        ?CALL   UMSTA
        ?CALL   DROP
        ?RET

;       M*              ( n n -- d )
;               Signed multiply. Return double product.

        ?COLON  2,'M*',MSTAR
        ?CALL   DDUP
        ?CALL   XORR
        ?CALL   ZLESS
        ?CALL   TOR
        ?CALL   ABSS
        ?CALL   SWAPP
        ?CALL   ABSS
        ?CALL   UMSTA
        ?CALL   RFROM
        ?CALL   QBRAN
        ?DW     MSTA1
        ?CALL   DNEGA
MSTA1:  ?RET

;       */MOD   ( n1 n2 n3 -- r q )
;               Multiply n1 and n2, then divide by n3. Return mod and quotient.

        ?COLON  5,'*/MOD',SSMOD
        ?CALL   TOR
        ?CALL   MSTAR
        ?CALL   RFROM
        ?CALL   MSMOD
        ?RET

;       */              ( n1 n2 n3 -- q )
;               Multiply n1 by n2, then divide by n3. Return quotient only.

        ?COLON  2,'*/',STASL
        ?CALL   SSMOD
        ?CALL   SWAPP
        ?CALL   DROP
        ?RET

;; Miscellaneous

;       BL              ( -- 32 )
;        ?RETurn 32, the blank character.

        ?COLON  2,'BL',BLANK
        ?CALL   DOLIT
        ?DW     32
        ?RET

;       0       ( -- 0 )
;        Return 0.

        ?CODE   1,'0',ZERO
        INC     R0      ;push tos
        MOV     @R0,TPL
        INC     R0
        MOV     @R0,TPH
        MOV     R2,#0
        MOV     R3,TPL
        RET

;       1       ( -- 1 )
;        Return 1.

        ?CODE   1,'1',ONE
        INC     R0      ;push tos
        MOV     @R0,TPL
        INC     R0
        MOV     @R0,TPH
        MOV     R2,#1
        MOV     R3,#0
        RET

;       2       ( -- 2 )
;        Return 2.

        ?CODE   1,'2',TWO
        INC     R0      ;push tos
        MOV     @R0,TPL
        INC     R0
        MOV     @R0,TPH
        MOV     R2,#2
        MOV     R3,#0
        RET

;       -1      ( -- -1 )
;        Return -1.

        ?CODE   2,'-1',MONE
        INC     R0      ;push tos
        MOV     @R0,TPL
        INC     R0
        MOV     @R0,TPH
        MOV     R2,#0FFH
        MOV     R3,TPL
        RET

;       >CHAR   ( c -- c )
;               Filter non-printing characters.

        ?COLON  5,'>CHAR',TCHAR
        ?CALL   DOLIT
        ?DW     07FH
        ?CALL   ANDD
        ?CALL   DUPP    ;mask msb
        ?CALL   DOLIT
        ?DW     127
        ?CALL   BLANK
        ?CALL   WITHI   ;check for printable
        ?CALL   QBRAN
        ?DW     TCHA1
        ?CALL   DROP
        ?CALL   DOLIT
        ?DW     5FH     ;'_'    ;replace non-printables
TCHA1:  ?RET

;       DEPTH   ( -- n )
;        Return the depth of the data stack.

        ?COLON  5,'DEPTH',DEPTH
        ?CALL   SPAT
        ?CALL   SZERO
        ?CALL   ATT
;        ?CALL  SWAPP   ;stack grows up,v2.1
        ?CALL   SUBBB
        ?CALL   TWOSL
;        ?CALL  DOLIT
;        ?DW    CELLL
;        ?CALL  SLASH
        ?RET

;       PICK    ( ... +n -- ... w )
;               Copy the nth stack item to tos.

        ?CODE   4,'PICK',PICK
        MOV     B,R0
        MOV     A,R0
        CLR     C
        SUBB    A,R2
        SUBB    A,R2
        MOV     R0,A
        MOV     TPH,@R0
        DEC     R0
        MOV     TPL,@R0
        MOV     R0,B
        RET

;; Memory access

;       +!              ( n a -- )
;               Add n to the contents at address a.

        ?COLON  2,'+!',PSTOR
        ?CALL   SWAPP
        ?CALL   OVER
        ?CALL   ATT
        ?CALL   PLUS
        ?CALL   SWAPP
        ?CALL   STORE
        ?RET

;       2!              ( d a -- )
;               Store the double integer to address a.

        ?COLON  2,'2!',DSTOR
        ?CALL   SWAPP
        ?CALL   OVER
        ?CALL   STORE
        ?CALL   CELLP
        ?CALL   STORE
        ?RET

;       2@              ( a -- d )
;               Fetch double integer from address a.

        ?COLON  2,'2@',DAT
        ?CALL   DUPP
        ?CALL   CELLP
        ?CALL   ATT
        ?CALL   SWAPP
        ?CALL   ATT
        ?RET

;       COUNT   ( b -- b +n )
;        ?RETurn count byte of a string and add 1 to byte address.

        ?COLON  5,'COUNT',COUNT
        ?CALL   DUPP
        ?CALL   ONEP
        ?CALL   SWAPP
        ?CALL   CAT
        ?RET

;       HERE    ( -- a )
;        ?RETurn the top of the code dictionary.

        ?COLON  4,'HERE',HERE
        ?CALL   CP
        ?CALL   ATT
        ?RET

;       PAD             ( -- a )
;        ?RETurn the address of the text buffer above the code dictionary.

        ?COLON  3,'PAD',PAD
        ?CALL   HERE
        ?CALL   DOLIT
        ?DW     256
        ?CALL   PLUS
        ?RET

;       TIB             ( -- a )
;        ?RETurn the address of the terminal input buffer.

        ?COLON  3,'TIB',TIB
        ?CALL   NTIB
        ?CALL   CELLP
        ?CALL   ATT
        ?RET

;       @EXECUTE        ( a -- )
;               Execute vector stored in address a.

        ?COLON  8,'@EXECUTE',ATEXE
        ?CALL   ATT
        ?CALL   QDUP    ;?address or zero
        ?CALL   QBRAN
        ?DW     EXE1
        ?CALL   EXECU   ;execute if non-zero
EXE1:   ?RET    ;do nothing if zero

;       CMOVE   ( b1 b2 u -- )
;               Copy u bytes from b1 to b2.

        ?COLON  5,'CMOVE',CMOVE
        ?CALL   TOR
        ?CALL   BRAN
        ?DW     CMOV2
CMOV1:  ?CALL   TOR
        ?CALL   DUPP
        ?CALL   CAT
        ?CALL   RAT
        ?CALL   CSTOR
        ?CALL   ONEP
        ?CALL   RFROM
        ?CALL   ONEP
CMOV2:  ?CALL   DONXT
        ?DW     CMOV1
        ?CALL   DDROP
        ?RET

;       FILL    ( b u c -- )
;               Fill u bytes of character c to area beginning at b.

        ?COLON  4,'FILL',FILL
        ?CALL   SWAPP
        ?CALL   TOR
        ?CALL   SWAPP
        ?CALL   BRAN
        ?DW     FILL2
FILL1:  ?CALL   DDUP
        ?CALL   CSTOR
        ?CALL   ONEP
FILL2:  ?CALL   DONXT
        ?DW     FILL1
        ?CALL   DDROP
        ?RET

;       -TRAILING       ( b u -- b u )
;               Adjust the count to eliminate trailing white space.

        ?COLON  9,'-TRAILING',DTRAI
        ?CALL   TOR
        ?CALL   BRAN
        ?DW     DTRA2
DTRA1:  ?CALL   BLANK
        ?CALL   OVER
        ?CALL   RAT
        ?CALL   PLUS
        ?CALL   CAT
        ?CALL   LESS
        ?CALL   QBRAN
        ?DW     DTRA2
        ?CALL   RFROM
        ?CALL   ONEP
        ?RET
DTRA2:  ?CALL   DONXT
        ?DW     DTRA1
        ?CALL   ZERO
        ?RET

;       PACK$   ( b u a -- a )
;               Build a counted string with u characters from b. Null fill.

        ?COLON  5,'PACK$',PACKS
        ?CALL   ALGND
PACKS1:  ?CALL  DUPP
        ?CALL   TOR     ;strings only on cell boundary
        ?CALL   OVER
        ?CALL   DUPP
        ?CALL   ONE
        ?CALL   ANDD    ;count mod cell
        ?CALL   SUBBB
        ?CALL   OVER
        ?CALL   PLUS
        ?CALL   ZERO
        ?CALL   SWAPP
        ?CALL   STORE   ;null fill cell
        ?CALL   DDUP
        ?CALL   CSTOR
        ?CALL   ONEP
        ?CALL   SWAPP
        ?CALL   CMOVE
        ?CALL   RFROM
        ?RET    ;move string

;; Numeric output, single precision

;       DIGIT   ( u -- c )
;               Convert digit u to a character.

        ?COLON  5,'DIGIT',DIGIT
        ?CALL   DOLIT
        ?DW     9
        ?CALL   OVER
        ?CALL   LESS
        ?CALL   DOLIT
        ?DW     7
        ?CALL   ANDD
        ?CALL   PLUS
        ?CALL   DOLIT
        ?DW     30H     ;'0'
        ?CALL   PLUS
        ?RET

;       EXTRACT ( n base -- n c )
;               Extract the least significant digit from n.

        ?COLON  7,'EXTRACT',EXTRC
        ?CALL   ZERO
        ?CALL   SWAPP
        ?CALL   UMMOD
        ?CALL   SWAPP
        ?CALL   DIGIT
        ?RET

;       <#              ( -- )
;               Initiate the numeric output process.

        ?COLON  2,'<#',BDIGS
        ?CALL   PAD
        ?CALL   HLD
        ?CALL   STORE
        ?RET

;       HOLD    ( c -- )
;               Insert a character into the numeric output string.

        ?COLON  4,'HOLD',HOLD
        ?CALL   HLD
        ?CALL   ATT
        ?CALL   ONEM
        ?CALL   DUPP
        ?CALL   HLD
        ?CALL   STORE
        ?CALL   CSTOR
        ?RET

;       #               ( u -- u )
;               Extract one digit from u and append the digit to output string.

        ?COLON  1,'#',DIG
        ?CALL   BASE
        ?CALL   ATT
        ?CALL   EXTRC
        ?CALL   HOLD
        ?RET

;       #S              ( u -- 0 )
;               Convert u until all digits are added to the output string.

        ?COLON  2,'#S',DIGS
DIGS1:  ?CALL   DIG
        ?CALL   DUPP
        ?CALL   QBRAN
        ?DW     DIGS2
        ?CALL   BRAN
        ?DW     DIGS1
DIGS2:  ?RET

;       SIGN    ( n -- )
;               Add a minus sign to the numeric output string.

        ?COLON  4,'SIGN',SIGN
        ?CALL   ZLESS
        ?CALL   QBRAN
        ?DW     SIGN1
        ?CALL   DOLIT
        ?DW     2DH     ;'-'
        ?CALL   HOLD
SIGN1:  ?RET

;       #>              ( w -- b u )
;               Prepare the output string to be TYPE'd.

        ?COLON  2,'#>',EDIGS
        ?CALL   DROP
        ?CALL   HLD
        ?CALL   ATT
        ?CALL   PAD
        ?CALL   OVER
        ?CALL   SUBBB
        ?RET

;       str             ( w -- b u )
;               Convert a signed integer to a numeric string.

        ?COLON  3,'str',STR
        ?CALL   DUPP
        ?CALL   TOR
        ?CALL   ABSS
        ?CALL   BDIGS
        ?CALL   DIGS
        ?CALL   RFROM
        ?CALL   SIGN
        ?CALL   EDIGS
        ?RET

;       HEX             ( -- )
;               Use radix 16 as base for numeric conversions.

        ?COLON  3,'HEX',HEX
        ?CALL   DOLIT
        ?DW     16
        ?CALL   BASE
        ?CALL   STORE
        ?RET

;       DECIMAL ( -- )
;               Use radix 10 as base for numeric conversions.

        ?COLON  7,'DECIMAL',DECIM
        ?CALL   DOLIT
        ?DW     10
        ?CALL   BASE
        ?CALL   STORE
        ?RET

;; Numeric input, single precision

;       DIGIT?  ( c base -- u t )
;               Convert a character to its numeric value. A flag indicates success.

        ?COLON  6,'DIGIT?',DIGTQ
        ?CALL   TOR
        ?CALL   DOLIT
        ?DW     30H     ;'0'
        ?CALL   SUBBB
        ?CALL   DOLIT
        ?DW     9
        ?CALL   OVER
        ?CALL   LESS
        ?CALL   QBRAN
        ?DW     DGTQ1
        ?CALL   DOLIT
        ?DW     7
        ?CALL   SUBBB
        ?CALL   DUPP
        ?CALL   DOLIT
        ?DW     10
        ?CALL   LESS
        ?CALL   ORR
DGTQ1:  ?CALL   DUPP
        ?CALL   RFROM
        ?CALL   ULESS
        ?RET

;       NUMBER? ( a -- n T | a F )
;               Convert a number string to integer. Push a flag on tos.

        ?COLON  7,'NUMBER?',NUMBQ
        ?CALL   BASE
        ?CALL   ATT
        ?CALL   TOR
        ?CALL   ZERO
        ?CALL   OVER
        ?CALL   COUNT
        ?CALL   OVER
        ?CALL   CAT
        ?CALL   DOLIT
        ?DW     24H     ;'$'
        ?CALL   EQUAL
        ?CALL   QBRAN
        ?DW     NUMQ1
        ?CALL   HEX
        ?CALL   SWAPP
        ?CALL   ONEP
        ?CALL   SWAPP
        ?CALL   ONEM
NUMQ1:  ?CALL   OVER
        ?CALL   CAT
        ?CALL   DOLIT
        ?DW     2DH     ;'-'
        ?CALL   EQUAL
        ?CALL   TOR
        ?CALL   SWAPP
        ?CALL   RAT
        ?CALL   SUBBB
        ?CALL   SWAPP
        ?CALL   RAT
        ?CALL   PLUS
        ?CALL   QDUP
        ?CALL   QBRAN
        ?DW     NUMQ6
        ?CALL   ONEM
        ?CALL   TOR
NUMQ2:  ?CALL   DUPP
        ?CALL   TOR
        ?CALL   CAT
        ?CALL   BASE
        ?CALL   ATT
        ?CALL   DIGTQ
        ?CALL   QBRAN
        ?DW     NUMQ4
        ?CALL   SWAPP
        ?CALL   BASE
        ?CALL   ATT
        ?CALL   STAR
        ?CALL   PLUS
        ?CALL   RFROM
        ?CALL   ONEP
        ?CALL   DONXT
        ?DW     NUMQ2
        ?CALL   RAT
        ?CALL   SWAPP
        ?CALL   DROP
        ?CALL   QBRAN
        ?DW     NUMQ3
        ?CALL   NEGAT
NUMQ3:  ?CALL   SWAPP
        ?CALL   BRAN
        ?DW     NUMQ5
NUMQ4:  ?CALL   RFROM
        ?CALL   RFROM
        ?CALL   DDROP
        ?CALL   DDROP
        ?CALL   ZERO
NUMQ5:  ?CALL   DUPP
NUMQ6:  ?CALL   RFROM
        ?CALL   DDROP
        ?CALL   RFROM
        ?CALL   BASE
        ?CALL   STORE
        ?RET

;; Basic I/O

;       ?KEY    ( -- c T | F )
;        ?RETurn input character and true, or a false if no input.

        ?COLON  4,'?KEY',QKEY
        ?CALL   TQKEY
        ?CALL   ATEXE
        ?RET

;       KEY             ( -- c )
;               Wait for and return an input character.

        ?COLON  3,'KEY',KEY
KEY1:   ?CALL   QKEY
        ?CALL   QBRAN
        ?DW     KEY1
        ?RET

;       EMIT    ( c -- )
;               Send a character to the output device.

        ?COLON  4,'EMIT',EMIT
        ?CALL   TEMIT
        ?CALL   ATEXE
        ?RET

;       NUF?    ( -- t )
;        ?RETurn false if no input, else pause and if CR return true.

        ?COLON  4,'NUF?',NUFQ
        ?CALL   QKEY
        ?CALL   DUPP
        ?CALL   QBRAN
        ?DW     NUFQ1
        ?CALL   DDROP
        ?CALL   KEY
        ?CALL   DOLIT
        ?DW     CRR
        ?CALL   EQUAL
NUFQ1:  ?RET

;       PACE    ( -- )
;               Send a pace character for the file downloading process.

        ?COLON  4,'PACE',PACE
        ?CALL   DOLIT
        ?DW     11
        ?CALL   EMIT
        ?RET

;       SPACE   ( -- )
;               Send the blank character to the output device.

        ?COLON  5,'SPACE',SPACE
        ?CALL   BLANK
        ?CALL   EMIT
        ?RET

;       SPACES  ( +n -- )
;               Send n spaces to the output device.

        ?COLON  6,'SPACES',SPACS
        ?CALL   ZERO
        ?CALL   MAX
        ?CALL   TOR
        ?CALL   BRAN
        ?DW     CHAR2
CHAR1:  ?CALL   SPACE
CHAR2:  ?CALL   DONXT
        ?DW     CHAR1
        ?RET

;       TYPE    ( b u -- )
;               Output u characters from b.

        ?COLON  4,'TYPE',TYPES
        ?CALL   TOR
        ?CALL   BRAN
        ?DW     TYPE2
TYPE1:  ?CALL   DUPP
        ?CALL   CAT
        ?CALL   EMIT
        ?CALL   ONEP
TYPE2:  ?CALL   DONXT
        ?DW     TYPE1
        ?CALL   DROP
        ?RET

;       CR              ( -- )
;               Output a carriage return and a line feed.

        ?COLON  2,'CR',CR
        ?CALL   DOLIT
        ?DW     CRR
        ?CALL   EMIT
;        ?CALL  DOLIT   ;auto lf for 68HC11
;        ?DW    LF
;        ?CALL  EMIT
        ?RET

;       do$             ( -- a )
;        ?RETurn the address of a compiled string.

        ?COLON  COMPO+3,'do$',DOSTR
        ?CALL   RFROM
        ?CALL   RAT
        ?CALL   RFROM
        ?CALL   COUNT
        ?CALL   PLUS
;        ?CALL  ALGND  take out for 8086
        ?CALL   TOR
        ?CALL   SWAPP
        ?CALL   TOR
        ?RET

;       $"|             ( -- a )
;               Run time routine compiled by $". Return address of a compiled string.

        ?COLON  COMPO+3,'$"|',STRQP
        ?CALL   DOSTR
        ?RET    ;force a call to do$

;       ."|             ( -- )
;               Run time routine of ." . Output a compiled string.

        ?COLON  COMPO+3,'."|',DOTQP
        ?CALL   DOSTR
        ?CALL   COUNT
        ?CALL   TYPES
        ?RET

;       .R              ( n +n -- )
;               Display an integer in a field of n columns, right justified.

        ?COLON  2,'.R',DOTR
        ?CALL   TOR
        ?CALL   STR
        ?CALL   RFROM
        ?CALL   OVER
        ?CALL   SUBBB
        ?CALL   SPACS
        ?CALL   TYPES
        ?RET

;       U.R             ( u +n -- )
;               Display an unsigned integer in n column, right justified.

        ?COLON  3,'U.R',UDOTR
        ?CALL   TOR
        ?CALL   BDIGS
        ?CALL   DIGS
        ?CALL   EDIGS
        ?CALL   RFROM
        ?CALL   OVER
        ?CALL   SUBBB
        ?CALL   SPACS
        ?CALL   TYPES
        ?RET

;       U.              ( u -- )
;               Display an unsigned integer in free format.

        ?COLON  2,'U.',UDOT
        ?CALL   BDIGS
        ?CALL   DIGS
        ?CALL   EDIGS
        ?CALL   SPACE
        ?CALL   TYPES
        ?RET

;       .               ( w -- )
;               Display an integer in free format, preceeded by a space.

        ?COLON  1,'.',DOT
        ?CALL   BASE
        ?CALL   ATT
        ?CALL   DOLIT
        ?DW     10
        ?CALL   XORR    ;?decimal
        ?CALL   QBRAN
        ?DW     DOT1
        ?CALL   UDOT
        ?RET    ;no, display unsigned
DOT1:   ?CALL   STR
        ?CALL   SPACE
        ?CALL   TYPES
        ?RET    ;yes, display signed

;       ?               ( a -- )
;               Display the contents in a memory cell.

        ?COLON  1,'?',QUEST
        ?CALL   ATT
        ?CALL   DOT
        ?RET

;; Parsing

;       parse   ( b u c -- b u delta ; <string> )
;               Scan string delimited by c. Return found string and its offset.

        ?COLON  5,'parse',PARS
        ?CALL   TEMP
        ?CALL   STORE
        ?CALL   OVER
        ?CALL   TOR
        ?CALL   DUPP
        ?CALL   QBRAN
        ?DW     PARS8
        ?CALL   ONEM
        ?CALL   TEMP
        ?CALL   ATT
        ?CALL   BLANK
        ?CALL   EQUAL
        ?CALL   QBRAN
        ?DW     PARS3
        ?CALL   TOR
PARS1:  ?CALL   BLANK
        ?CALL   OVER
        ?CALL   CAT     ;skip leading blanks ONLY
        ?CALL   SUBBB
        ?CALL   ZLESS
        ?CALL   INVER
        ?CALL   QBRAN
        ?DW     PARS2
        ?CALL   ONEP
        ?CALL   DONXT
        ?DW     PARS1
        ?CALL   RFROM
        ?CALL   DROP
        ?CALL   ZERO
        ?CALL   DUPP
        ?RET
PARS2:  ?CALL   RFROM
PARS3:  ?CALL   OVER
        ?CALL   SWAPP
        ?CALL   TOR
PARS4:  ?CALL   TEMP
        ?CALL   ATT
        ?CALL   OVER
        ?CALL   CAT
        ?CALL   SUBBB   ;scan for delimiter
        ?CALL   TEMP
        ?CALL   ATT
        ?CALL   BLANK
        ?CALL   EQUAL
        ?CALL   QBRAN
        ?DW     PARS5
        ?CALL   ZLESS
PARS5:  ?CALL   QBRAN
        ?DW     PARS6
        ?CALL   ONEP
        ?CALL   DONXT
        ?DW     PARS4
        ?CALL   DUPP
        ?CALL   TOR
        ?CALL   BRAN
        ?DW     PARS7
PARS6:  ?CALL   RFROM
        ?CALL   DROP
        ?CALL   DUPP
        ?CALL   ONEP
        ?CALL   TOR
PARS7:  ?CALL   OVER
        ?CALL   SUBBB
        ?CALL   RFROM
        ?CALL   RFROM
        ?CALL   SUBBB
        ?RET
PARS8:  ?CALL   OVER
        ?CALL   RFROM
        ?CALL   SUBBB
        ?RET

;       PARSE   ( c -- b u ; <string> )
;               Scan input stream and return counted string delimited by c.

        ?COLON  5,'PARSE',PARSE
        ?CALL   TOR
        ?CALL   TIB
        ?CALL   INN
        ?CALL   ATT
        ?CALL   PLUS    ;current input buffer pointer
        ?CALL   NTIB
        ?CALL   ATT
        ?CALL   INN
        ?CALL   ATT
        ?CALL   SUBBB   ;remaining count
        ?CALL   RFROM
        ?CALL   PARS
        ?CALL   INN
        ?CALL   PSTOR
        ?RET

;       .(              ( -- )
;               Output following string up to next ) .

        ?COLON  IMEDD+2,'.(',DOTPR
        ?CALL   DOLIT
        ?DW     29H     ;')'
        ?CALL   PARSE
        ?CALL   TYPES
        ?RET

;       (               ( -- )
;               Ignore following string up to next ) . A comment.

        ?COLON  IMEDD+1,'(',PAREN
        ?CALL   DOLIT
        ?DW     29H     ;')'
        ?CALL   PARSE
        ?CALL   DDROP
        ?RET

;       \               ( -- )
;               Ignore following text till the end of line.

        ?COLON  IMEDD+1,'\',BKSLA
        ?CALL   NTIB
        ?CALL   ATT
        ?CALL   INN
        ?CALL   STORE
        ?RET

;       CHAR    ( -- c )
;               Parse next word and return its first character.

        ?COLON  4,'CHAR',CHAR
        ?CALL   BLANK
        ?CALL   PARSE
        ?CALL   DROP
        ?CALL   CAT
        ?RET

;       TOKEN   ( -- a ; <string> )
;               Parse a word from input stream and copy it to name dictionary.

        ?COLON  5,'TOKEN',TOKEN
        ?CALL   BLANK
        ?CALL   PARSE
        ?CALL   DOLIT
        ?DW     31
        ?CALL   MIN
        ?CALL   CP      ;changed for combined headers
        ?CALL   ATT
        ?CALL   ALGND
;       ?CALL   CELLP   ;leave space for code pointer
        ?CALL   CELLP   ;leave space for link field
        ?CALL   PACKS
        ?RET

;       WORD    ( c -- a ; <string> )
;               Parse a word from input stream and copy it to code dictionary.

        ?COLON  4,'WORD',WORDD
        ?CALL   PARSE
        ?CALL   HERE
        ?CALL   PACKS1
        ?RET

;; Dictionary search

;       NAME>   ( na -- ca )
;        Return a code address given a name address.

        ?COLON  5,'NAME>',NAMET
        ?CALL   COUNT
        ?CALL   DOLIT
        ?DW     31
        ?CALL   ANDD
        ?CALL   PLUS
        ?CALL   ALGND
        ?RET

;       SAME?   ( a a u -- a a f \ -0+ )
;               Compare u cells in two strings. Return 0 if identical.

        ?COLON  5,'SAME?',SAMEQ
        ?CALL   TOR
        ?CALL   BRAN
        ?DW     SAME2
SAME1:  ?CALL   OVER
        ?CALL   RAT
        ?CALL   CELLS
        ?CALL   PLUS
        ?CALL   ATT
        ?CALL   OVER
        ?CALL   RAT
        ?CALL   CELLS
        ?CALL   PLUS
        ?CALL   ATT
        ?CALL   SUBBB
        ?CALL   QDUP
        ?CALL   QBRAN
        ?DW     SAME2
        ?CALL   RFROM
        ?CALL   DROP
        ?RET
SAME2:  ?CALL   DONXT
        ?DW     SAME1
        ?CALL   ZERO
        ?RET

;       find    ( a va -- ca na | a F )
;               Search a vocabulary for a string. Return ca and na if succeeded.

        ?COLON  4,'find',FIND
        ?CALL   SWAPP
        ?CALL   DUPP
        ?CALL   CAT
        ?CALL   TWOSL
;        ?CALL  DOLIT
;        ?DW    CELLL
;        ?CALL  SLASH
        ?CALL   TEMP
        ?CALL   STORE
        ?CALL   DUPP
        ?CALL   ATT
        ?CALL   TOR
        ?CALL   CELLP
        ?CALL   SWAPP
FIND1:  ?CALL   ATT
        ?CALL   DUPP
        ?CALL   QBRAN
        ?DW     FIND6
        ?CALL   DUPP
        ?CALL   ATT
        ?CALL   DOLIT
        ?DW     MASKK
        ?CALL   ANDD
        ?CALL   RAT
        ?CALL   XORR
        ?CALL   QBRAN
        ?DW     FIND2
        ?CALL   CELLP
        ?CALL   MONE
        ?CALL   BRAN
        ?DW     FIND3
FIND2:  ?CALL   CELLP
        ?CALL   TEMP
        ?CALL   ATT
        ?CALL   SAMEQ
FIND3:  ?CALL   BRAN
        ?DW     FIND4
FIND6:  ?CALL   RFROM
        ?CALL   DROP
        ?CALL   SWAPP
        ?CALL   CELLM
        ?CALL   SWAPP
        ?RET
FIND4:  ?CALL   QBRAN
        ?DW     FIND5
        ?CALL   CELLM
        ?CALL   CELLM
        ?CALL   BRAN
        ?DW     FIND1
FIND5:  ?CALL   RFROM
        ?CALL   DROP
        ?CALL   SWAPP
        ?CALL   DROP
        ?CALL   CELLM
        ?CALL   DUPP
        ?CALL   NAMET
        ?CALL   SWAPP
        ?RET

;       NAME?   ( a -- ca na | a F )
;               Search all context vocabularies for a string.

        ?COLON  5,'NAME?',NAMEQ
        ?CALL   CNTXT
        ?CALL   DUPP
        ?CALL   DAT
        ?CALL   XORR
        ?CALL   QBRAN
        ?DW     NAMQ1
        ?CALL   CELLM
NAMQ1:  ?CALL   TOR
NAMQ2:  ?CALL   RFROM
        ?CALL   CELLP
        ?CALL   DUPP
        ?CALL   TOR
        ?CALL   ATT
        ?CALL   QDUP
        ?CALL   QBRAN
        ?DW     NAMQ3
        ?CALL   FIND
        ?CALL   QDUP
        ?CALL   QBRAN
        ?DW     NAMQ2
        ?CALL   RFROM
        ?CALL   DROP
        ?RET
NAMQ3:  ?CALL   RFROM
        ?CALL   DROP
        ?CALL   ZERO
        ?RET

;; Terminal response

;       ^H              ( bot eot cur -- bot eot cur )
;               Backup the cursor by one character.

        ?COLON  2,'^H',BKSP
        ?CALL   TOR
        ?CALL   OVER
        ?CALL   RFROM
        ?CALL   SWAPP
        ?CALL   OVER
        ?CALL   XORR
        ?CALL   QBRAN
        ?DW     BACK1
        ?CALL   DOLIT
        ?DW     BKSPP
        ?CALL   TECHO
        ?CALL   ATEXE
        ?CALL   ONEM
        ?CALL   BLANK
        ?CALL   TECHO
        ?CALL   ATEXE
        ?CALL   DOLIT
        ?DW     BKSPP
        ?CALL   TECHO
        ?CALL   ATEXE
BACK1:  ?RET

;       TAP             ( bot eot cur c -- bot eot cur )
;               Accept and echo the key stroke and bump the cursor.

        ?COLON  3,'TAP',TAP
        ?CALL   DUPP
        ?CALL   TECHO
        ?CALL   ATEXE
        ?CALL   OVER
        ?CALL   CSTOR
        ?CALL   ONEP
        ?RET


;       kTAP    ( bot eot cur c -- bot eot cur )
;               Process a key stroke, CR or backspace.

        ?COLON  4,'kTAP',KTAP
        ?CALL   DUPP
        ?CALL   DOLIT
        ?DW     CRR
        ?CALL   XORR
        ?CALL   QBRAN
        ?DW     KTAP2
        ?CALL   DOLIT
        ?DW     BKSPP
        ?CALL   XORR
        ?CALL   QBRAN
        ?DW     KTAP1
        ?CALL   BLANK
        ?CALL   TAP
        ?RET
KTAP1:  ?CALL   BKSP
        ?RET
KTAP2:  ?CALL   DROP
        ?CALL   SWAPP
        ?CALL   DROP
        ?CALL   DUPP
                ?CALL SPACE
        ?RET

;       accept  ( b u -- b u )
;               Accept characters to input buffer. Return with actual count.

        ?COLON  6,'accept',ACCEP
        ?CALL   OVER
        ?CALL   PLUS
        ?CALL   OVER
ACCP1:  ?CALL   DDUP
        ?CALL   XORR
        ?CALL   QBRAN
        ?DW     ACCP4
        ?CALL   KEY
        ?CALL   DUPP
        ?CALL   BLANK
        ?CALL   DOLIT
        ?DW     127
        ?CALL   WITHI
        ?CALL   QBRAN
        ?DW     ACCP2
        ?CALL   TAP
        ?CALL   BRAN
        ?DW     ACCP3
ACCP2:  ?CALL   TTAP
        ?CALL   ATEXE
ACCP3:  ?CALL   BRAN
        ?DW     ACCP1
ACCP4:  ?CALL   DROP
        ?CALL   OVER
        ?CALL   SUBBB
        ?RET

;       EXPECT  ( b u -- )
;               Accept input stream and store count in SPAN.

        ?COLON  6,'EXPECT',EXPEC
        ?CALL   TEXPE
        ?CALL   ATEXE
        ?CALL   SPAN
        ?CALL   STORE
        ?CALL   DROP
        ?RET

;       QUERY   ( -- )
;               Accept input stream to terminal input buffer.

        ?COLON  5,'QUERY',QUERY
        ?CALL   TIB
        ?CALL   DOLIT
        ?DW     80
        ?CALL   TEXPE
        ?CALL   ATEXE
        ?CALL   NTIB
        ?CALL   STORE
        ?CALL   DROP
        ?CALL   ZERO
        ?CALL   INN
        ?CALL   STORE
        ?RET

;; Error handling

;       CATCH   ( ca -- 0 | err# )
;               Execute word at ca and set up an error frame for it.

        ?COLON  5,'CATCH',CATCH
        ?CALL   SPAT
        ?CALL   TOR
        ?CALL   HANDL
        ?CALL   ATT
        ?CALL   TOR     ;save error frame
        ?CALL   RPAT
        ?CALL   HANDL
        ?CALL   STORE
        ?CALL   EXECU   ;execute
        ?CALL   RFROM
        ?CALL   HANDL
        ?CALL   STORE   ;restore error frame
        ?CALL   RFROM
        ?CALL   DROP
        ?CALL   ZERO
        ?RET    ;no error

;       THROW   ( err# -- err# )
;               Reset system to current local error frame an update error flag.

        ?COLON  5,'THROW',THROW
        ?CALL   HANDL
        ?CALL   ATT
        ?CALL   RPSTO   ;restore return stack
        ?CALL   RFROM
        ?CALL   HANDL
        ?CALL   STORE   ;restore handler frame
        ?CALL   RFROM
        ?CALL   SWAPP
        ?CALL   TOR
        ?CALL   SPSTO   ;restore data stack
        ?CALL   DROP
        ?CALL   RFROM
        ?RET

;       NULL$   ( -- a )
;        ?RETurn address of a null string with zero count.

        ?COLON  5,'NULL$',NULLS
        ?CALL   DOVAR   ;emulate CREATE
        ?DW     0
                DB      99,111,121,111,116,101

;       ABORT   ( -- )
;               Reset data stack and jump to QUIT.

        ?COLON  5,'ABORT',ABORT
        ?CALL   NULLS
        ?CALL   THROW

;       abort"  ( f -- )
;               Run time routine of ABORT" . Abort with a message.

        ?COLON  COMPO+6,'abort"',ABORQ
        ?CALL   QBRAN
        ?DW     ABOR1   ;text flag
        ?CALL   DOSTR
                ?CALL   COUNT
                ?CALL   TYPES
        ?CALL   ABORT   ;pass error string
ABOR1:  ?CALL   DOSTR
        ?CALL   DROP
        ?RET    ;drop error

;; The text interpreter

;       $INTERPRET      ( a -- )
;               Interpret a word. If failed, try to convert it to an integer.

        ?COLON  10,'$INTERPRET',INTER
        ?CALL   NAMEQ
        ?CALL   QDUP    ;?defined
        ?CALL   QBRAN
        ?DW     INTE1
        ?CALL   ATT
        ?CALL   DOLIT
        ?DWLEX  COMPO
        ?CALL   ANDD    ;?compile only lexicon bits
        ?CALL   ABORQ
                DB      13,' compile only'
        ?CALL   EXECU
        ?RET    ;execute defined word
INTE1:  ?CALL   TNUMB
        ?CALL   ATEXE   ;convert a number
        ?CALL   QBRAN
        ?DW     INTE2
        ?RET
INTE2:  ?CALL   THROW   ;error

;       [               ( -- )
;               Start the text interpreter.

        ?COLON  IMEDD+1,'[',LBRAC
        ?CALL   DOLIT
        ?DW     INTER
        ?CALL   TEVAL
        ?CALL   STORE
        ?RET

;       .OK             ( -- )
;               Display 'ok' only while interpreting.

        ?COLON  3,'.OK',DOTOK
        ?CALL   DOLIT
        ?DW     INTER
        ?CALL   TEVAL
        ?CALL   ATT
        ?CALL   EQUAL
        ?CALL   QBRAN
        ?DW     DOTO1
        ?CALL   DOTQP
                DB      3,' ok'
DOTO1:  ?CALL   CR
        ?RET

;       ?STACK  ( -- )
;               Abort if the data stack underflows.

        ?COLON  6,'?STACK',QSTAC
        ?CALL   DEPTH
        ?CALL   ZLESS   ;check only for underflow
        ?CALL   ABORQ
                DB      10,' underflow'
        ?RET

;       EVAL    ( -- )
;               Interpret the input stream.

        ?COLON  4,'EVAL',EVAL
EVAL1:  ?CALL   TOKEN
        ?CALL   DUPP
        ?CALL   CAT     ;?input stream empty
        ?CALL   QBRAN
        ?DW     EVAL2
        ?CALL   TEVAL
        ?CALL   ATEXE
        ?CALL   QSTAC   ;evaluate input, check stack
        ?CALL   BRAN
        ?DW     EVAL1
EVAL2:  ?CALL   DROP
        ?CALL   TPROM
        ?CALL   ATEXE
        ?RET    ;prompt

;; Shell

;       PRESET  ( -- )
;               Reset data stack pointer and the terminal input buffer.

        ?COLON  6,'PRESET',PRESE
        ?CALL   SZERO
        ?CALL   ATT
        ?CALL   SPSTO
        ?CALL   DOLIT
        ?DW     TIBB
        ?CALL   NTIB
        ?CALL   CELLP
        ?CALL   STORE
        ?RET

;       xio             ( a a a -- )
;               Reset the I/O vectors 'EXPECT, 'TAP, 'ECHO and 'PROMPT.

        ?COLON  COMPO+3,'xio',XIO
        ?CALL   DOLIT
        ?DW     ACCEP
        ?CALL   TEXPE
        ?CALL   DSTOR
        ?CALL   TECHO
        ?CALL   DSTOR
        ?RET

;       FILE    ( -- )
;               Select I/O vectors for file download.

        ?COLON  4,'FILE',FILE
        ?CALL   DOLIT
        ?DW     PACE
        ?CALL   DOLIT
        ?DW     DROP
        ?CALL   DOLIT
        ?DW     KTAP
        ?CALL   XIO
        ?RET

;       HAND    ( -- )
;               Select I/O vectors for terminal interface.

        ?COLON  4,'HAND',HAND
        ?CALL   DOLIT
        ?DW     DOTOK
        ?CALL   DOLIT
        ?DW     EMIT
        ?CALL   DOLIT
        ?DW     KTAP
        ?CALL   XIO
        ?RET

;       I/O             ( -- a )
;               Array to store default I/O vectors.

        ?COLON  3,'I/O',ISLO
        ?CALL   DOVAR   ;emulate CREATE
        ?DW     QRX
        ?DW     TXSTO   ;default I/O vectors

;       CONSOLE ( -- )
;               Initiate terminal interface.

        ?COLON  7,'CONSOLE',CONSO
        ?CALL   ISLO
        ?CALL   DAT
        ?CALL   TQKEY
        ?CALL   DSTOR   ;restore default I/O device
        ?CALL   HAND
        ?RET    ;keyboard input

;       QUIT    ( -- )
;               Reset return stack pointer and start text interpreter.

        ?COLON  4,'QUIT',QUIT
        ?CALL   RZERO
        ?CALL   ATT
        ?CALL   RPSTO   ;reset return stack pointer
QUIT1:  ?CALL   LBRAC   ;start interpretation
QUIT2:  ?CALL   QUERY   ;get input
        ?CALL   DOLIT
        ?DW     EVAL
        ?CALL   CATCH
        ?CALL   QDUP    ;evaluate input
        ?CALL   QBRAN
        ?DW     QUIT2   ;continue till error
        ?CALL   TPROM
        ?CALL   ATT
        ?CALL   TOR     ;save input device
        ?CALL   CONSO
        ?CALL   NULLS
        ?CALL   OVER
        ?CALL   XORR    ;?display error message
        ?CALL   QBRAN
        ?DW     QUIT3
        ?CALL   SPACE
        ?CALL   COUNT
        ?CALL   TYPES   ;error message
        ?CALL   DOTQP
                DB      3,' ? ' ;error prompt
                ?CALL   CR
QUIT3:  ?CALL   RFROM
        ?CALL   DOLIT
        ?DW     DOTOK
        ?CALL   XORR    ;?file input
        ?CALL   QBRAN
        ?DW     QUIT4
        ?CALL   DOLIT
        ?DW     ERR
        ?CALL   EMIT    ;file error, tell host
QUIT4:  ?CALL   PRESE   ;some cleanup
        ?CALL   BRAN
        ?DW     QUIT1

;; The compiler

;       '               ( -- ca )
;               Search context vocabularies for the next word in input stream.

        ?COLON  1,27H,TICK
        ?CALL   TOKEN
        ?CALL   NAMEQ   ;?defined
        ?CALL   QBRAN
        ?DW     TICK1
        ?RET    ;yes, push code address
TICK1:  ?CALL   THROW   ;no, error

;       ALLOT   ( n -- )
;               Allocate n bytes to the code dictionary.

        ?COLON  5,'ALLOT',ALLOT
        ?CALL   CP
        ?CALL   PSTOR
        ?RET    ;adjust code pointer

;       ,               ( w -- )
;               Compile an integer into the code dictionary.

        ?COLON  1,2CH,COMMA
        ?CALL   HERE
        ?CALL   DUPP
        ?CALL   CELLP
        ?CALL   CP
        ?CALL   STORE
        ?CALL   STORE
        ?RET

;       C,              ( c -- )
;               Compile a byte (char) into the code dictionary.

        ?COLON  2,'C.',CCOMMA
        ?CALL   HERE
        ?CALL   DUPP
        ?CALL   ONEP
        ?CALL   CP      ;adjust code pointer
        ?CALL   STORE
        ?CALL   CSTOR   ;C! byte
        ?RET

;       [COMPILE]       ( -- ; <string> )
;               Compile the next immediate word into code dictionary.

        ?COLON  IMEDD+9,'[COMPILE]',BCOMP
        ?CALL   TICK
        ?CALL   COMMA
        ?RET

;       COMPILE ( -- )
;               Compile the next address in colon list to code dictionary.

        ?COLON  COMPO+7,'COMPILE',COMPI
        ?CALL   RFROM
        ?CALL   DUPP
        ?CALL   ATT
        ?CALL   COMMA   ;compile address
        ?CALL   CELLP
        ?CALL   TOR
        ?RET    ;adjust return address

;       LITERAL ( w -- )
;               Compile tos to code dictionary as an integer literal.

        ?COLON  IMEDD+7,'LITERAL',LITER
        ?CALL   DOLIT
        ?DW     DOLIT
        ?CALL   CALLC
        ?CALL   COMMA
        ?RET

;       $,"             ( -- )
;               Compile a literal string up to next " .

        ?COLON  3,'$."',STRCQ
        ?CALL   DOLIT
        ?DW     22H     ;'"'
        ?CALL   WORDD   ;move string to code dictionary
;;      ?CALL   ALGND   ; sub threaded-skip nulls
        ?CALL   COUNT
        ?CALL   PLUS
;        ?CALL  ALGND   ;calculate aligned end of string
        ?CALL   CP
        ?CALL   STORE
        ?RET    ;adjust the code pointer

;       RECURSE ( -- )
;               Make the current word available for compilation.

        ?COLON  IMEDD+7,'RECURSE',RECUR
        ?CALL   LAST
        ?CALL   ATT
        ?CALL   NAMET
        ?CALL   COMMA
        ?RET

;; Structures

;       FOR             ( -- a )
;               Start a FOR-NEXT loop structure in a colon definition.

        ?COLON  IMEDD+3,'FOR',FOR
        ?CALL   DOLIT
        ?DW     TOR
        ?CALL   CALLC
        ?CALL   HERE
        ?RET

;       BEGIN   ( -- a )
;               Start an infinite or indefinite loop structure.

        ?COLON  IMEDD+5,'BEGIN',BEGIN
        ?CALL   HERE
        ?RET

;       NEXT    ( a -- )
;               Terminate a FOR-NEXT loop structure.

        ?COLON  IMEDD+4,'NEXT',NEXT
        ?CALL   DOLIT
        ?DW     DONXT
        ?CALL   CALLC
        ?CALL   COMMA
        ?RET

;       UNTIL   ( a -- )
;               Terminate a BEGIN-UNTIL indefinite loop structure.

        ?COLON  IMEDD+5,'UNTIL',UNTIL
        ?CALL   DOLIT
        ?DW     QBRAN
        ?CALL   CALLC
        ?CALL   COMMA
        ?RET

;       AGAIN   ( a -- )
;               Terminate a BEGIN-AGAIN infinite loop structure.

        ?COLON  IMEDD+5,'AGAIN',AGAIN
        ?CALL   DOLIT
        ?DW     BRAN
        ?CALL   CALLC
        ?CALL   COMMA
        ?RET

;       IF              ( -- A )
;               Begin a conditional branch structure.

        ?COLON  IMEDD+2,'IF',IFF
        ?CALL   DOLIT
        ?DW     QBRAN
        ?CALL   CALLC
        ?CALL   HERE
        ?CALL   ZERO
        ?CALL   COMMA
        ?RET

;       AHEAD   ( -- A )
;               Compile a forward branch instruction.

        ?COLON  IMEDD+5,'AHEAD',AHEAD
        ?CALL   DOLIT
        ?DW     BRAN
        ?CALL   CALLC
        ?CALL   HERE
        ?CALL   ZERO
        ?CALL   COMMA
        ?RET

;       REPEAT  ( A a -- )
;               Terminate a BEGIN-WHILE-REPEAT indefinite loop.

        ?COLON  IMEDD+6,'REPEAT',REPEA
        ?CALL   AGAIN
        ?CALL   HERE
        ?CALL   SWAPP
        ?CALL   STORE
        ?RET

;       THEN    ( A -- )
;               Terminate a conditional branch structure.

        ?COLON  IMEDD+4,'THEN',THENN
        ?CALL   HERE
        ?CALL   SWAPP
        ?CALL   STORE
        ?RET

;       AFT             ( a -- a A )
;               Jump to THEN in a FOR-AFT-THEN-NEXT loop the first time through.

        ?COLON  IMEDD+3,'AFT',AFT
        ?CALL   DROP
        ?CALL   AHEAD
        ?CALL   BEGIN
        ?CALL   SWAPP
        ?RET

;       ELSE    ( A -- A )
;               Start the false clause in an IF-ELSE-THEN structure.

        ?COLON  IMEDD+4,'ELSE',ELSEE
        ?CALL   AHEAD
        ?CALL   SWAPP
        ?CALL   THENN
        ?RET

;       WHILE   ( a -- A a )
;               Conditional branch out of a BEGIN-WHILE-REPEAT loop.

        ?COLON  IMEDD+5,'WHILE',WHILE
        ?CALL   IFF
        ?CALL   SWAPP
        ?RET

;       ABORT"  ( -- ; <string> )
;               Conditional abort with an error message.

        ?COLON  IMEDD+6,'ABORT"',ABRTQ
        ?CALL   DOLIT
        ?DW     ABORQ
        ?CALL   CALLC
        ?CALL   STRCQ
        ?RET

;       $"              ( -- ; <string> )
;               Compile an inline string literal.

        ?COLON  IMEDD+2,'$"',STRQ
        ?CALL   DOLIT
        ?DW     STRQP
        ?CALL   CALLC
        ?CALL   STRCQ
        ?RET

;       ."              ( -- ; <string> )
;               Compile an inline string literal to be typed out at run time.

        ?COLON  IMEDD+2,'."',DOTQ
        ?CALL   DOLIT
        ?DW     DOTQP
        ?CALL   CALLC
        ?CALL   STRCQ
        ?RET

;; Name compiler

;       ?UNIQUE ( a -- a )
;               Display a warning message if the word already exists.

        ?COLON  7,'?UNIQUE',UNIQU
        ?CALL   DUPP
        ?CALL   NAMEQ   ;?name exists
        ?CALL   QBRAN
        ?DW     UNIQ1
        ?CALL   DOTQP   ;redefinitions are OK
                DB      7,' reDef '             ;but the user should be warned
        ?CALL   OVER
        ?CALL   COUNT
        ?CALL   TYPES   ;just in case its not planned
UNIQ1:  ?CALL   DROP
        ?RET

;       $,n             ( na -- )
;               Build a new dictionary name using the string at na.

        ?COLON  3,'$.n',SNAME
        ?CALL   DUPP
        ?CALL   CAT     ;?null input
        ?CALL   QBRAN
        ?DW     PNAM1
        ?CALL   UNIQU   ;?redefinition
        ?CALL   DUPP
        ?CALL   LAST
        ?CALL   STORE   ;save na for vocabulary link
        ?CALL   DUPP    ;changed for single header
        ?CALL   DUPP
        ?CALL   CAT
        ?CALL   PLUS
        ?CALL   ONEP
        ?CALL   ALGND
;        ?CALL  DUPP
        ?CALL   CP
        ?CALL   STORE
;        ?CALL  SWAPP   ; ca na --
        ?CALL   CELLM   ;link address
        ?CALL   CRRNT
        ?CALL   ATT
        ?CALL   ATT
        ?CALL   SWAPP
;        ?CALL  OVER
        ?CALL   STORE   ;extend link chain
;        ?CALL  CELLM
;        ?CALL  STORE   ;save code pointer
        ?RET
PNAM1:  ?CALL   STRQP
        DB      5,' name'       ;null input
        ?CALL   THROW

;; FORTH compiler

;       $COMPILE        ( a -- )
;               Compile next word to code dictionary as a token or literal.

        ?COLON  8,'$COMPILE',SCOMP
        ?CALL   NAMEQ
        ?CALL   QDUP    ;?defined
        ?CALL   QBRAN
        ?DW     SCOM2
        ?CALL   ATT
        ?CALL   DOLIT
        ?DWLEX  IMEDD
        ?CALL   ANDD    ;?immediate
        ?CALL   QBRAN
        ?DW     SCOM1
        ?CALL   EXECU
        ?RET    ;its immediate, execute
SCOM1:  ?CALL   CALLC
        ?RET    ;its not immediate, compile
SCOM2:  ?CALL   TNUMB
        ?CALL   ATEXE   ;try to convert to number
        ?CALL   QBRAN
        ?DW     SCOM3
        ?CALL   LITER
        ?RET    ;compile number as integer
SCOM3:  ?CALL   THROW   ;error

;       OVERT   ( -- )
;               Link a new word into the current vocabulary.

        ?COLON  5,'OVERT',OVERT
        ?CALL   LAST
        ?CALL   ATT
        ?CALL   CRRNT
        ?CALL   ATT
        ?CALL   STORE
        ?RET

;       ;               ( -- )
;               Terminate a colon definition.

        ?COLON  IMEDD+COMPO+1,3BH,SEMIS
        ?CALL   DOLIT
        ?DW     RETT
        ?CALL   CCOMMA
        ?CALL   LBRAC
        ?CALL   OVERT
        ?RET

;       ]               ( -- )
;               Start compiling the words in the input stream.

        ?COLON  1,']',RBRAC
        ?CALL   DOLIT
        ?DW     SCOMP
        ?CALL   TEVAL
        ?CALL   STORE
        ?RET

;       call,   ( ca -- )
;               Assemble a call instruction to ca.

        ?COLON  4,'CALL',CALLC
        ?CALL   DOLIT
        ?DW     CALLL
        ?CALL   CCOMMA
        ?CALL   FLIP    ;8051 LCALL address is big-endian
        ?CALL   COMMA
        ?RET

;       :               ( -- ; <string> )
;               Start a new colon definition using next word as its name.

        ?COLON  1,':',COLON
        ?CALL   TOKEN
        ?CALL   SNAME
        ?CALL   RBRAC
        ?RET

;       IMMEDIATE       ( -- )
;               Make the last compiled word an immediate word.

        ?COLON  9,'IMMEDIATE',IMMED
        ?CALL   DOLIT
        ?DWLEX  IMEDD
        ?CALL   LAST
        ?CALL   ATT
        ?CALL   ATT
        ?CALL   ORR
        ?CALL   LAST
        ?CALL   ATT
        ?CALL   STORE
        ?RET

;; Defining words

;       USER    ( u -- ; <string> )
;               Compile a new user variable.

        ?COLON  4,'USER',USER
        ?CALL   TOKEN
        ?CALL   SNAME
        ?CALL   OVERT
        ?CALL   DOLIT
        ?DW     DOUSE
        ?CALL   CALLC
        ?CALL   COMMA
        ?RET

;       CREATE  ( -- ; <string> )
;               Compile a new array entry without allocating code space.

        ?COLON  6,'CREATE',CREAT
        ?CALL   TOKEN
        ?CALL   SNAME
        ?CALL   OVERT
        ?CALL   DOLIT
        ?DW     DOVAR
        ?CALL   CALLC
        ?RET

;       VARIABLE        ( -- ; <string> )
;               Compile a new variable initialized to 0.

        ?COLON  8,'VARIABLE',VARIA
        ?CALL   CREAT
        ?CALL   ZERO
        ?CALL   COMMA
        ?RET

;; Tools

;       _TYPE   ( b u -- )
;               Display a string. Filter non-printing characters.

        ?COLON  5,'_TYPE',UTYPE
        ?CALL   TOR     ;start count down loop
        ?CALL   BRAN
        ?DW     UTYP2   ;skip first pass
UTYP1:  ?CALL   DUPP
        ?CALL   CAT
        ?CALL   TCHAR
        ?CALL   EMIT    ;display only printable
        ?CALL   ONEP
UTYP2:  ?CALL   DONXT
        ?DW     UTYP1   ;loop till done
        ?CALL   DROP
        ?RET

;       dm+             ( a u -- a )
;               Dump u bytes from , leaving a+u on the stack.

        ?COLON  3,'dm+',DUMPP
        ?CALL   OVER
        ?CALL   DOLIT
        ?DW     4
        ?CALL   UDOTR   ;display address
        ?CALL   SPACE
        ?CALL   TOR     ;start count down loop
        ?CALL   BRAN
        ?DW     PDUM2   ;skip first pass
PDUM1:  ?CALL   DUPP
        ?CALL   CAT
        ?CALL   DOLIT
        ?DW     3
        ?CALL   UDOTR   ;display numeric data
        ?CALL   ONEP
PDUM2:  ?CALL   DONXT
        ?DW     PDUM1   ;loop till done
        ?RET

;       DUMP    ( a u -- )
;               Dump u bytes from a, in a formatted manner.

        ?COLON  4,'DUMP',DUMP
        ?CALL   BASE
        ?CALL   ATT
        ?CALL   TOR
        ?CALL   HEX     ;save radix, set hex
        ?CALL   DOLIT
        ?DW     16
        ?CALL   SLASH   ;change count to lines
        ?CALL   TOR     ;start count down loop
DUMP1:  ?CALL   CR
        ?CALL   DOLIT
        ?DW     16
        ?CALL   DDUP
        ?CALL   DUMPP   ;display numeric
        ?CALL   ROT
        ?CALL   ROT
        ?CALL   TWO
        ?CALL   SPACS
        ?CALL   UTYPE   ;display printable characters
        ?CALL   NUFQ
        ?CALL   INVER   ;user control
        ?CALL   QBRAN
        ?DW     DUMP2
        ?CALL   DONXT
        ?DW     DUMP1   ;loop till done
        ?CALL   BRAN
        ?DW     DUMP3
DUMP2:  ?CALL   RFROM
        ?CALL   DROP    ;cleanup loop stack, early exit
DUMP3:  ?CALL   DROP
        ?CALL   RFROM
        ?CALL   BASE
        ?CALL   STORE   ;restore radix
        ?RET

;       .S              ( ... -- ... )
;               Display the contents of the data stack.

        ?COLON  2,'.S',DOTS
        ?CALL   CR
        ?CALL   DEPTH   ;stack depth
        ?CALL   TOR     ;start count down loop
        ?CALL   BRAN
        ?DW     DOTS2   ;skip first pass
DOTS1:  ?CALL   RAT
        ?CALL   PICK
        ?CALL   DOT     ;index stack, display contents
DOTS2:  ?CALL   DONXT
        ?DW     DOTS1   ;loop till done
        ?CALL   DOTQP
                DB      4,' <sp'
        ?RET

;       !CSP    ( -- )
;               Save stack pointer in CSP for error checking.

        ?COLON  4,'!CSP',STCSP
        ?CALL   SPAT
        ?CALL   CSP
        ?CALL   STORE
        ?RET    ;save pointer

;       ?CSP    ( -- )
;               Abort if stack pointer differs from that saved in CSP.

        ?COLON  4,'?CSP',QCSP
        ?CALL   SPAT
        ?CALL   CSP
        ?CALL   ATT
        ?CALL   XORR    ;compare pointers
        ?CALL   ABORQ   ;abort if different
                DB      6,'stacks'
        ?RET

;       >NAME   ( ca -- na | F )
;               Convert code address to a name address.

        ?COLON  5,'>NAME',TNAME
        ?CALL   CRRNT   ;vocabulary link
TNAM1:  ?CALL   CELLP
        ?CALL   ATT
        ?CALL   QDUP    ;check all vocabularies
        ?CALL   QBRAN
        ?DW     TNAM4
        ?CALL   DDUP
TNAM2:  ?CALL   ATT
        ?CALL   DUPP    ;?last word in a vocabulary
        ?CALL   QBRAN
        ?DW     TNAM3
        ?CALL   DDUP
        ?CALL   NAMET
        ?CALL   XORR    ;compare
        ?CALL   QBRAN
        ?DW     TNAM3
        ?CALL   CELLM   ;continue with next word
        ?CALL   BRAN
        ?DW     TNAM2
TNAM3:  ?CALL   SWAPP
        ?CALL   DROP
        ?CALL   QDUP
        ?CALL   QBRAN
        ?DW     TNAM1
        ?CALL   SWAPP
        ?CALL   DROP
        ?CALL   SWAPP
        ?CALL   DROP
        ?RET
TNAM4:  ?CALL   DROP
        ?CALL   ZERO
        ?RET

;       .ID             ( na -- )
;               Display the name at address.

        ?COLON  3,'.ID',DOTID
        ?CALL   QDUP    ;if zero no name
        ?CALL   QBRAN
        ?DW     DOTI1
        ?CALL   COUNT
        ?CALL   DOLIT
        ?DW     01FH
        ?CALL   ANDD    ;mask lexicon bits
        ?CALL   UTYPE
        ?RET    ;display name string
DOTI1:  ?CALL   DOTQP
                DB      9,' {noName}'
        ?RET

;       SEE             ( -- ; <string> )
;               A simple decompiler.

        ?COLON  3,'SEE',SEE
        ?CALL   TICK    ;starting address
        ?CALL   CR
SEE1:   ?CALL   COUNT
        ?CALL   DUPP    ;?does it contain a zero
        ?CALL   DOLIT
        ?DW     12H
        ?CALL   XORR
        ?CALL   QBRAN
        ?DW     SEE2
        ?CALL   DOT
        ?CALL   BRAN
        ?DW     SEE4
SEE2:   ?CALL   DROP
        ?CALL   DUPP
        ?CALL   ATT
        ?CALL   FLIP
        ?CALL   TNAME
        ?CALL   SPACE
        ?CALL   DOTID   ;display name
        ?CALL   CELLP
SEE4:   ?CALL   NUFQ    ;user control
        ?CALL   QBRAN
        ?DW     SEE1
        ?CALL   DROP
        ?RET

;       WORDS   ( -- )
;               Display the names in the context vocabulary.

        ?COLON  5,'WORDS',WORDS
        ?CALL   CR
        ?CALL   CNTXT
        ?CALL   ATT     ;only in context
WORS1:  ?CALL   ATT
        ?CALL   QDUP    ;?at end of list
        ?CALL   QBRAN
        ?DW     WORS2
        ?CALL   DUPP
        ?CALL   SPACE
        ?CALL   DOTID   ;display a name
        ?CALL   CELLM
        ?CALL   NUFQ    ;user control
        ?CALL   QBRAN
        ?DW     WORS1
        ?CALL   DROP
WORS2:  ?RET

;       READ    ( a # -- )
;       Read a file into file buffer at PAD.
;       Terminated by ESC, total bytes stored in CSP.

        ?COLON  4,'READ',READ
        ?CALL OVER
        ?CALL   CSP
        ?CALL   STORE
        ?CALL   TOR
READ1:
        ?CALL   KEY
        ?CALL   DUPP
        ?CALL   DOLIT
        ?DW     27
        ?CALL   XORR
        ?CALL   QBRAN
        ?DW     READ2
;       ?CALL   DUPP
;       ?CALL   DOLIT
;       ?DW     0DH
;       ?CALL   EQUAL
;       ?CALL   QBRAN
;       ?DW     READ4
;       ?CALL   DOLIT
;       ?DW     2EH
;       ?CALL   TXSTO
READ4:
        ?CALL   OVER
        ?CALL   CSTOR
        ?CALL   ONEP
        ?CALL   DONXT
        ?DW     READ1
        ?CALL   DROP
        ?CALL   BRAN
        ?DW     READ3
READ2:
        ?CALL   RFROM
        ?CALL   DDROP
READ3:
        ?CALL   CSP
        ?CALL   ATT
        ?CALL   SUBBB
        ?CALL   CSP
        ?CALL   STORE
        ?RET


;       LOAD    ( a # -- )
;       Load a file in the file buffer at PAD.
;       Use total bytes stored in CSP.

        ?COLON  4,'LOAD',LOAD
        ?CALL   INN
        ?CALL   ATT
        ?CALL   NTIB
        ?CALL   DAT             ;save >IN,#TIB,TIB
        ?CALL   TOR
        ?CALL   TOR
        ?CALL   TOR             
        ?CALL   DOLIT
        ?DW     0
        ?CALL   INN
        ?CALL   STORE           ;init >IN
        ?CALL   NTIB
        ?CALL   STORE           ;init #TIB and TIB
        ?CALL   NTIB
        ?CALL   CELLP
        ?CALL   STORE
        ?CALL   EVAL    ;load source
        ?CALL   RFROM
        ?CALL   RFROM
        ?CALL   RFROM           ;restore >IN,#TIB,TIB
        ?CALL   NTIB
        ?CALL   DSTOR
        ?CALL   INN
        ?CALL   STORE
        ?RET

;       SEND    ( -- )
;       Dump range of memory in Intel Hex format, to be written
;       to PROM.

        ?COLON  4,'SEND',SEND
        ?CALL   HEX
        ?CALL   TOR
        ?CALL   BRAN
        ?DW     SEND5
SEND1:
        ?CALL   DUPP
        ?CALL   DOLIT
        ?DW     31
        ?CALL   ANDD
        ?CALL   QBRAN
        ?DW     SEND2
        ?CALL   BRAN
        ?DW     SEND3
SEND2:
        ?CALL   CR
        ?CALL   DUPP
        ?CALL   DOLIT
        ?DW     0FFH
        ?CALL   ANDD
        ?CALL   CSP
        ?CALL   STORE
        ?CALL   DUPP
        ?CALL   DOLIT
        ?DW     100H
        ?CALL   SLASH
        ?CALL   CSP
        ?CALL   PSTOR
        ?CALL	DOLIT
	?DW	20H
	?CALL	CSP
	?CALL	PSTOR
	?CALL	DOTQP
	DB	3,':20'
	?CALL	DUPP
	?CALL	BDIGS
	?CALL	DIG
	?CALL	DIG
	?CALL	DIG
	?CALL	DIG
	?CALL	EDIGS
	?CALL	TYPES
	?CALL	DOTQP
	DB	2,'00'
SEND3:
	?CALL	COUNT
	?CALL	DUPP
	?CALL	CSP
	?CALL	PSTOR
	?CALL	BDIGS
	?CALL	DIG
	?CALL	DIG
	?CALL	EDIGS
	?CALL	TYPES
	?CALL	DUPP
	?CALL	DOLIT
	?DW	31
	?CALL	ANDD
	?CALL	QBRAN
	?DW	SEND4
	?CALL	BRAN
	?DW	SEND5
SEND4:	?CALL	CSP
	?CALL	CAT
	?CALL	NEGAT
	?CALL	BDIGS
	?CALL	DIG
	?CALL	DIG
	?CALL	EDIGS
	?CALL	TYPES
SEND5:	?CALL	DONXT
	?DW	SEND1
	?CALL	CR
	?CALL	DROP
	?CALL	DOTQP
	DB	11,':00000001FF'
	?CALL	CR
	?RET

;	FORGET	( -- ; <string> )
;	Trim the Forth vocabulary to the next word.
;	A dumb FORGET, no good for multiple vocabulary treads.

	?COLON	6,'FORGET',FORGET
	?CALL	TICK	;starting address
	?CALL	TNAME
	?CALL	CELLM
	?CALL	DUPP
	?CALL	CP
	?CALL	STORE
	?CALL	ATT
	?CALL	DUPP
	?CALL	LAST
	?CALL	DSTOR
	?RET


;; Har?CALLare reset

;	VER		( -- n )
;	 ?RETurn the version number of this implementation.

	?COLON  3,'VER',VERSN
	?CALL	DOLIT
	DB	VER
	DB	EXT
	?RET

;	hi		( -- )
;		Display the sign-on message of eForth.

	?COLON  2,'hi',HI
	?CALL	STOIO
	?CALL	CR
	?CALL	DOTQP	;initialize I/O
		DB	11,'eForth v'		;model
		DB	VER+'0','.',EXT+'0'	;version
	?CALL	CR
	?RET

;	'BOOT	( -- a )
;		The application startup vector.

	?COLON  5,'''BOOT',TBOOT
	?CALL	DOVAR
	?DW	HI	;application to boot

;	COLD	( -- )
;		The hilevel cold start sequence.

	?COLON  4,'COLD',COLD
COLD1:	?CALL	DOLIT
	?DW	UZERO
	?CALL	DOLIT
	?DW	UPP
	?CALL	DOLIT
	?DW	_ULMUZ	;ULAST-UZERO
	?CALL	CMOVE	;initialize user area
	?CALL	PRESE	;initialize data stack and TIB
	?CALL	TBOOT
	?CALL	ATEXE	;application boot
	?CALL	FORTH
	?CALL	CNTXT
	?CALL	ATT
	?CALL	DUPP	;initialize search order
	?CALL	CRRNT
	?CALL	DSTOR
	?CALL	OVERT
	?CALL	QUIT	;start interpretation
	?CALL	BRAN
	?DW	COLD1	;just in case

;===============================================================

LASTN	EQU	_LINK	;last name address in name dictionary

NTOP	EQU	_NAME	;next available memory in name dictionary
CTOP	EQU	_NAME	;next available memory in code dictionary

	END

