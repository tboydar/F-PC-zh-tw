Introduction to 2181eForth 


C. H. Ting

eForth is a public domain Forth system for embedded microprocessors.  
It was designed to be easily portable to new processors.  Currently
we have about 20 implementations for various microprocessors and
micro-controllers.

This tutorial is aimed at the first time eForth users to learn the
basic instruction set of 2181 eForth so that they can use it for productive
work in a very short period of time.  Only about 70 instructions will
be discussed in this tutorial.  Nevertheless, this small set of instructions
allows the user to express fairly sophisticated algorithms needed in
solving many practical problems.  It thus lays down a solid foundation
for further study of the Forth language and other Forth systems.

This tutorial contains 12 files with 17 examples and exercises.
The source code comes with the descriptive text so that the user
does not have to type in the code.  The lessons can be 'compiled'
by eForth and all the examples can be tested by the user immediately.

Here I will show you how to get the eForth started and a few of the 
instructions you have to used to compile the lessons, read the tutorial
text, test the examples, and do the exercises.  You may not become
a professional Forth programmer right away, but it should give you
a taste on what Forth is and what it can do for you.  Then you can
start do some simple programs yourself, explore the rich ground
of the Forth language.


1.      Starting 2181eForth

This eForth is installed in a 1MB EPROM plugged into the Analog Devices
EZKIT-Lite, ADSP2181 EZ-LAB board. The label is 2181EF2.1.  This board
communicates with the PC through the HyperTerminal utiltity in Windows.
Boot up your PC, and select HyperTerminal in the Accessory menu.  When
HyperTerminal is up, go to the file menu and click Properties.  There 
you have to configure HperTerminal to talk to the COM port connected to
the EZ-LAB board, and set up it to talk at 9600 baud, 1 start bit, 8 data
bits, 1 stop bit, no parity, no flow control.  In the ASCII configuration
menu, set 1 ms delay after each character, and 100 ms after every line.
You may have to exit HyterTerminal and re-enter it so that the baud rate
will take effect.

Now power up EZ-LAB.  Both the green and red LED will turn on.  eForth will
now send the following sign-on message to HyperTerminal:

	2181 eForth v2.1

eForth is now running, and it is ready to receive your commands.


2.	Get to Know eForth

Most of the eForth commands are in upper case.  Press Caps Lock key before 
you proceed.

Here are a few commands you can exercise and get acquainted with eForth:

	WORDS <return>

eForth will display a list of all the commands in the system.  You can type 
the name of most the commands and test them.

	HERE .  <return>

prints out the memory location of the top of the code dictionary.  Area about 
HERE will be used compile new commands.

Type:

	1 2 + . <return>

and a 3 will be displayed by the command '.' showing the results of 1+2.  

Type a sequence of numbers:

	1 2 3 4 5 <return>

The numbers are pushed on the data stack.  If you like to see what is on the
stack, type:

	.S <return>

and your will see:

	1 2 3 4 5 <sp ok

.S dumps the data stack without disturbing the stack.  In contrast, the command
'.' (dot) removes the number from the stack after displaying it.

To see what the code dictionary looks like, type:

	HEX 20 80 PDUMP <return>

eForth will dump the 128 words of program memory of from location 20 and up.
The byte dump generally is not very informative.  If you like to see the
contents of a eForth command, a decompiler can be very helpful:

	SEE WORDS <return>

The command SEE decompiles the command immediately follows it and displays a
list of commands that make up WORDS.  You can stop the decompiler by pressing
a key on the keyboard.

To see the data memory from location 180 and up, type:

	HEX 180 80 DUMP <return>

In 2181, the program memory is 24-bits wide, and the data memory is 16-bit
wide.  They are separated memory spaces, and both has the 16K word range 
from 0 to 3FFF.

These are the most useful utility commands in eForth:

	WORDS		Display commands in dictionary
	.S		Display the data stack
	PDUMP		Dump a range of program memory
	DUMP		Dump a range of data memory
	SEE		Decompile a command
	HEX		Switch to hexadecimal representation of numbers
	DECIMAL	Switch to decimal representation of numbers
	.		Display top number on data stack and remove it from
                  the stack


3.	Study the Lessons

There are 17 examples provided in the LESSON$.TXT file.  Print it
out and type in the text to experiment with them.  When you type,
you can ignore the parentheses and all the text enclosed in them.
The first example is then:

	: HELLO CR ." Hello, world!" ; <return>

The spaces between words are very important because the interpreter
uses space to parse out Forth commands.  After that, you can test the
new command:

	HELLO <return>

and eForth will respond:

	Hello, world! Ok

Pick any of the examples, and type in the text which adds new commands 
to eForth, and then execute them.  You have to do a few of these
examples to be familiar with eForth.

After your are comfortable with eForth, and can type in an example and
execute new commands correctly, you can exercise all the examples by 
loading each of the files LESSON1.TXT to LESSON12.TXT and compile all 
the examples from these files.  It is important that you configured the
HyperTerminal properly, with 1 ms delay after each character, and 100 ms
delay after each line.  The delays allow 2181 enough time to process
the characters and execute the commands.

In HyperTerminal, from the Transfer menu, select Send Text File option,
and you will see a file selection window, from which you can select one 
of the lessons.  The texts in the lesson file will be compiled as they 
are received by 2181.

There are 17 examples in the LESSON$.TXT files.  You compiled and 
test each and every commands defined in these files.  When you develop 
your own applications, you can use any text editor in Windows to 
compose the source code, and then load the file to test new commands
you defined in the text file.

With these examples, I hope you will learn how to write your own 
programs in 2181 eForth.


4.	Software Development for 2181

Currently, the 2181 eForth is only a shell for you to access 2181
interactively.  It is not yet a full software development system,
because you cannot easily enter code words which will access the full
power of 2181.  We need a 2181 assembler so the user can write routines
best optimized for DSP applications.  We also need an easy way to save
the image of a running system to be programmed into bootable EPROM.

These capabilities are not difficult to develop.  I will do it if there
is a serious application calling for them.

Actually, there is a Level 0 Assembler in 2181 eForth.  It is the all
purpose command "," (comma), which converts a double integer into a
24-bit word and pushes it on the top of the code dictionary.  If you
know the machine code routine in binary, you can comma these machine
instructions into the code dictionary and build code words.

To facilitate the compiler in eForth, I have defined three very useful
commands to compile some 2181 machine instructions:

	CALL,	( a -- )	Compile a call to the address
	JUMP,	( a -- )	Compile a jump to the address
	N,	( n -- )	Compile an ar=<value> machine instruction

These commands are a very small subset of the Level 1 Assembler, which
can be very useful for a Forth expert to assemble only the machine
instructions he need in a DSP application.  Since 2181 is subroutine
threaded, you can put 2181 machine instructions in-line with Forth
pseudo instructions which are simply subroutine calls.

2181 is a fairly complicated machine, and a complete assembler will be
as complicated.  It is not difficult.  Let us leave it as an exercise 
for the students.

In the mean time, you can still use this eForth as a shell, and add
your DSP applications to the source code of 2181 eForth.  You can then
use the assembler provided by Analog Devices to assemble it.  Analog
Devices also provides linker, simulator, and ROM splitter for you to
put your final system into bootable EPROM.

It is also possible to construct a "loader", which will dump the code
image and the necessary data into an ASCII file, like what is generated
by the ROM splitter SPL21 supplied by Analog Devices.  Again, this is
left as a challenge to the students.


5.	Deviations from the eForth Model

It you are familiar with the other eForth implementations, you should be
aware of the deviations of 2181 from the eForth model:

	Subroutine threaded model
	Headers in name dictionary has only a code pointer field and a
		name field.  Link field is eliminated.
	Names in the name field are assembled one character per word.
	Most arithmetic and logic words are in assembly
	The machine return stack is used as the Forth return stack.
	A loop stack is used for looping and >R, R@, R>.  The machine
		return stack is unsuitable because its width is 14-bits.
	User variables leaves absolute data memory address.
	There are three dictionary pointers:
		CP	point to top of code dictionary
		NP	point to bottom of name dictionary
		VP	point to top of variable area
	Code dictionary is in the 24-bit program memory, growing up.
	Name dictionary is in the 16-bit data memory, growing down.
	Variable area is in the 16-bit data memory, growing up.
	No inline data in the program memory.
	Numeric literal is compiled as:
		CALL DUP
		ar=<literal value>
	Branch structure is compiled as:
		CALL NOP
		JUMP <address>
	Condictional branch is compiled as:
		CALL QBRAN
		JUMP <address>
	Loop structures:
		CALL >R
	label: ...
		...
		CALL NEXT
		JUMP <label>
	String literal is the same as numeric literal, with the literal
		value as a pointer to the variable area. Strings are
		assembled in the variable area, not inline with code.
	The serial port is a bit-banging software UART.
		KEY monitors the flag input pin Flag_in.
		EMIT toggles the flag output pin Flag_out.
	No CATCH-THROW business.  All errors lead to ABORT.
	The return stack is only 16 levels deep. Do not nest too deep.  The
		system crashes when the return stack overflows.


6.	Conclusion

2181 is a very interesting chip.  It is optimized to do Multiply-Accumulate
in a single cycle, and is ideally suited for DSP applications which do
lots of multiplying and additions.  To me the most important feature is the
80 KB of RAM on board.  It can thus host an interactive Forth operating 
system for program development.

The Harvard architecture, however, leaves lots to be desired.  The design
is wasteful, and not very well adaptive to high level programming.  The
16 level return stack is too shallow for deep nesting.  The 4 level loop
stack is a joke.  The auto-motifying pointers are convenient for accessing
data arrays, but not good enough to implement stacks.  The separation of
data memory space from code memory space makes it very difficult to 
support Forth, which can manage data and code on equal footing.

The assembler ASM21 has the very serious shortfall in assembling data
inline with code.  It does not know how to handle character strings and
insists on assembling one character per 16-bit data word or 24-bit code
word.

The MONITOR program in EZ-LAB is also awkward.  It is almost interactive
through the serial port, but insists on transferring data in binary.  If
it were transferring data in ASCII, it could become a very nice monitor
usable on HyperTerminal.  As is, one has to communication withit through
the propietary EZ-KIT Lite Host program.

All these deficiencies cry out loudly for a better user interface, and
a better operating system.  This is what 2181 eForth aspires to be.
Right now, 2181 eForth is still very primitive.  Once we add the assembler
and the upload/download capabilities, it will be a complete DSP 
firmware development system.  When we convert all the DSP library routines
in the Analog Devices Handbooks into Forth, we will have the best DSP
programming system.