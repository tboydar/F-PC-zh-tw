/*********************************************************
*       2181eForth
*       10apr00cht, 2181EF, 2.0
*               PAD uses VP
*               compile LESSONS.TXT
*               add README.TXT
*               prepare release.
*
*       27jan00cht, 2181EF, 1.0
*
*	Virtural Forth Engine for 2181
*	ADSP2181 is very nice in having 80 KB of RAM memory
*	Subroutine threaded model
*	Hardware return stack is the Forth return stack
*	The return stack is only 16 levels deep.  Maybe a problem.
*	Top of data stack is AR, next is AY0
*	This optimizes the binary operations like +, -, AND...
*	Data stack pointer is i0, astack pointer is i3
*	User variables return hard data memory address
*	Both astack[32] and data stack[256] are circular
*	M0=0,M1=1,M2=2,M3=-1,M4=0,M5=1,M6=2,M7=-1
*	M2 and M6 can be freely used
*	L0=256, L3=32, L1=L2=L4=L5=L6=L7=0
*	i0 is post-incremented with M1 on pop
*		ar=pass ay0, ay0=dm(i0,m1);
*	i0 must be pre-decremented with M3 on push
*		modify(i0,m3); dm(i0,m0)=ay0; ay0=ar;
*	i3 is used for astack and temporary storage used by
*		>R, R@ and R>, which do not address the return stack
*	i4 usually mirrors top of return stack pcstack.
*	i1, i2, i4-i7 are free scratch registers
*	astack operators >A, A@, A> replace >R, R@, and R>
*	@ and ! operate on data memory, P@ and P! on program memory
*	P@ and P! access program memory in double integers, only
*		the lower 3 bytes are significant
*	DUMP dumps data memory, PDUMP dumps program memory
*	SEE decompiles 40 words
*	Code dictionary in program memory, top pointed by CP, growing up
*	Name dictionary in data memory, top pointed by NP, growing down
*	Variable stack is pointed by VP, growing up
*	Names in name dictionary are not packed, each byte to a word
*	Assembler very unfriendly in handling the data memory.
*		hence the names are not packed
*		impossible to interlace names with code in program memory
*		no DW or DB
*	Assembler:		ASM21 -L -2181 TEST >TEST.ERR
*	Linker:		LD21 TEST -a EZKIT_LT -e TEST -g -x
*	Simulator:		sim2181 -a ezkit_lt -e test
*	Simulator must be invoked in pure DOS mode
*	HyperTerminal is set to 9600 baud, 8 bit date, 1 start bit,
*		1 stop bit, no parity, no flow control
*		1 ms delay after each character, 100 ms after each line
*	LAST and CONTEXT point to code pointer field of last word
*	Header has only code pointer field and name field
*	Strings are stored on the variable stack with variables
*	String literals are literals returning address in variable stack
*	String words follows the string literals
*	KEY and EMIT bit-bang FLAG_IN and FLAG_OUT
*		KEY also toggles LED on FL1
*	No ?KEY, no NUF?
*	08mar00cht, assembled without the name dictionary in dm.
*		simulator SIM2181 only works in pure DOS.
*		Add DIAGNOSE
*	24mar00cht, interpreter starts working.
*               add nop's after toppcstack=ar
*	26mar00cht, add P@, P!, DSHIFT, PACK, COUNT#, THERE
*		Debug compiler
*	31mar00cht, remaining tasks: loops, string literals
*               using return stack, loops only do 16K cycles
*	03apr00cht, fix loops, add FORGET, compile all lessons.
*               add astack for loops and >R, R@, R>
*		general clean-up
*       10apr00cht, put eForth in ROM
*************************************************************/
.module/ram/abs=0    demo;       /* define the program module */ 
   
	jump COLD;	/* jump over interrupt vectors */ 
	nop; nop; nop;

	rti; rti; rti; rti;      /* code vectors here upon IRQ2 interrupt */ 
	rti; rti; rti; rti;      /* code vectors here upon IRQL1 interrupt */ 
	rti; rti; rti; rti;      /* code vectors here upon IRQL0 interrupt */ 
	rti; rti; rti; rti;      /* code vectors here upon SPORT0 TX interrupt */ 
	rti; rti; rti; rti;      /* code vectors here upon SPORT0 RX interrupt */ 
	
 /* code vectors here upon IRQE interrupt */	
	rti; rti; rti; rti;      /* set flag to non-zero value */
	
	rti; rti; rti; rti;      /* code vectors here upon BDMA interrupt */ 
	rti; rti; rti; rti;      /* code vectors here upon SPORT1 TX (IRQ1) interrupt */ 
	rti; rti; rti; rti;      /* code vectors here upon SPORT1 RX (IRQ0) interrupt */ 
	rti; rti; rti; rti;      /* code vectors here upon TIMER interrupt */ 
	rti; rti; rti; rti;      /* code vectors here upon POWER DOWN interrupt */ 

/**********************************************************/
.var/dm/circ/abs=0    datastack[256];
.var/dm/circ    astack[32];
.var/dm/ram     terminal[96];

.var/dm/ram MOK[5];
.init MOK:      4,' ok ';
.var/dm/ram MCOMPILE[14];
.init MCOMPILE: 13,' compile only';
.var/dm/ram MUNDER[12];
.init MUNDER:   11,' underflow ';
.var/dm/ram MREDEF[8];
.init MREDEF:   7,' reDef ';
.var/dm/ram MNAME[6];
.init MNAME:    5,' name';
.var/dm/ram MSP[6];
.init MSP:      5,' <sp ';
.var/dm/ram MNONAME[10];
.init MNONAME:  9,' {noName}';
.var/dm/ram MVERSION[16];
.init MVERSION: 15,'2181eForth v',0x32,'.',0X30;
.var/dm/ram FENCE[16];
.init FENCE: 11,'below fence';

.var/dm/ram     delay;
.var/dm/ram     rbase,rtemp,rin,rntib,rtib,reval,rhold;
.var/dm/ram		rcontext,rnp,rcp,rlast,rvp;
.init delay:	1719;
.init rbase:	10;
.init rtib:		^terminal;
.init reval:	^INTER;
.init rcontext: ^names;
.init rnp:	^names-1;
.init rcp:		^CPP;
.init rlast:    ^names;
.init rvp:		^variables;

.var/dm/ram     variables;

.const bottom = 0xF0;

.const VER     =     1	;
.const EXT     =     0	;
.const TRUEE   =     -1      ;
.const COMPO   =     0x40     ;
.const IMEDD   =     0x80     ;
.const MASKK   =     0x7F  ;
.const CELLL   =     2       ;
.const BASEE   =     10      ;
.const BKSPP   =     8       ;
.const LF      =     10      ;
.const CRR     =     13      ;
.const ERR     =     27      ;
.const TIC     =     39      ;
.const CALLL   =     0x16     ;

.var/dm/ram/abs=0x3000     names[0x800];
.init names:    
	^COLD,4,'COLD',
	^TBOOT,4,'BOOT',
	^HII,2,'HI',
	^FRGT,6,'FORGET',
	^WORDS,5,'WORDS',
	^SEE,3,'SEE',
	^ADDR,4,'ADDR',
	^DOTID,3,'.ID',
	^TNAME,5,'>NAME',
	^DOTS,2,'.S',
	^PDUMP,5,'PDUMP',
	^DUMP,4,'DUMP',
	^DUMPP,3,'DM+',
	^UTYPE,5,'_TYPE',
	^VARIA,8,'VARIABLE',
	^CREAT,6,'CREATE',
	^IMMED,9,'IMMEDIATE',
	^COLON,1,':',
	^RBRAC,1,']',
        ^SEMIS,0xC1,';',
	^OVERT,5,'OVERT',
	^SCOMP,8,'$COMPILE',
	^SNAME,3,'$,N',
	^UNIQU,7,'?UNIQUE',
        ^DOTQ,0xC2,'."',
        ^STRQ,0xC2,'$"',
        ^ABRTQ,0xC6,'ABORT"',
        ^AFT,0xC3,'AFT',
        ^REPEA,0xC6,'REPEAT',
        ^WHILE,0xC5,'WHILE',
        ^AHEAD,0xC5,'AHEAD',
        ^ELSEE,0xC4,'ELSE',
        ^THENN,0xC4,'THEN',
        ^IFF,0xC2,'IF',
        ^AGAINN,0xC5,'AGAIN',
        ^UNTILL,0xC5,'UNTIL',
        ^BEGINN,0xC5,'BEGIN',
        ^NEXT,0xC4,'NEXT',
        ^FOR,0xC3,'FOR',
	^STRCQ,3,'$,"',
	^LITER,7,'LITERAL',
	^COMPI,7,'COMPILE',
        ^BCOMP,0xC9,'[COMPILE]',
	^JUMPST,5,'JUMP!',
	^JUMPC,5,'JUMP,',
	^CALLC,5,'CALL,',
	^NCOMMA,2,'N',0x2C,
	^COMMA,1,0x2C,
	^VALLOT,6,'VALLOT',
	^ALLOT,5,'ALLOT',
	^TICK,1,0x27, 
	^QUIT,4,'QUIT',
	^PRESE,6,'PRESET',
	^EVAL,4,'EVAL',
	^QSTAC,6,'?STACK',
	^DOTOK,3,'.OK',
	^LBRAC,0x81,'[',
	^INTER,10,'$INTERPRET',
        ^ABRTQ,0xC6,'ABORT"',
	^ABORT,5,'ABORT',
	^QUERY,5,'QUERY',
	^ACCEP,6,'ACCEPT',
	^KTAP,4,'KTAP',
	^TAP,3,'TAP',
	^BKSP,2,'^H',
	^NAMEQ,5,'NAME?',
	^FIND,4,'FIND',
	^NAMET,5,'NAME>',
	^TOKEN,5,'TOKEN',
	^WORDD,4,'WORD',
	^BKSLA,0x81,0x5C,
	^PAREN,0x81,'(',
	^DOTPR,0x82,'.(',
	^PARSE,5,'PARSE',
	^PARS,4,'PARS',
	^QUEST,1,'?',
	^DOT,1,0x2E,
	^UDOT,2,'U.',
	^UDOTR,3,'U.R',
	^DOTR,2,'.R',
	^DOTQP,3,'."|',
	^STRQP,3,'$"|',
	^DOSTR,3,'DO$',
	^CR,2,'CR',
	^TYPES,4,'TYPE',
	^SPACS,6,'SPACES',
	^SPACE,5,'SPACE',
	^NUMBQ,7,'NUMBER?',
	^DIGTQ,6,'DIGIT?',
	^DECIM,7,'DECIMAL',
	^HEX,3,'HEX',
	^STR,3,'STR',
	^EDIGS,2,'#>',
	^SIGN,4,'SIGN',
	^DIGS,2,'#S',
	^DIG,1,'#',
	^HOLD,4,'HOLD',
	^BDIGS,2,'<#',
	^EXTRC,7,'EXTRACT',
	^DIGIT,5,'DIGIT',
	^PACKS,5,'PACK$',
	^ERASE,5,'ERASE',
	^FILL,4,'FILL',
	^CMOVE,5,'CMOVE',
	^ATEXE,8,'@EXECUTE',
	^TIB,3,'TIB',
	^PAD,3,'PAD',
	^THERE,5,'THERE',
        ^VHERE,5,'VHERE',
	^HERE,4,'HERE',
	^COUNTC,6,'COUNT#',
	^COUNT,5,'COUNT',
	^DAT,2,'2@',
	^DSTOR,2,'2!',
	^PSTOR,2,'+!',
	^PICK,4,'PICK',
	^DEPTH,5,'DEPTH',
	^TCHAR,5,'>CHAR',
	^MONE,2,'-1',
	^ONE,1,'1',
	^ZERO,1,'0',
	^BLANK,2,'BL',
	^TWOSL,2,'2/',
	^ONEM,2,'1-',
	^ONEP,2,'1+',
	^CELLS,2,'2*',
	^CELLM,2,'2-',
	^CELLP,2,'2+',
	^STARSL,2,0x2A,'/',
	^SSMOD,5,0x2A,'/MOD',
	^MSTAR,2,'M*',
	^STAR,1,'*',
	^UMSTA,3,'UM*',
	^SLASH,1,'/',
	^MODD,3,'MOD',
	^SLMOD,4,'/MOD',
	^MSMOD,5,'M/MOD',
	^UMMOD,6,'UM/MOD',
	^WITHI,6,'WITHIN',
	^MIN,3,'MIN',
	^MAX,3,'MAX',
	^LESS,1,'<',
	^ULESS,2,'U<',
	^EQUAL,1,'=',
	^ABSS,3,'ABS',
	^SUBB,1,'-',
	^DNEGA,7,'DNEGATE',
	^NEGAT,6,'NEGATE',
	^INVER,3,'NOT',
	^PLUS,1,'+',
	^DDUP,4,'2DUP',
	^DDROP,5,'2DROP',
	^ROT,3,'ROT',
	^QDUP,4,'?DUP',
	^LAST,4,'LAST',
	^VP,2,'VP',
	^NP,2,'NP',
	^CP,2,'CP',
	^CNTXT,7,'CONTEXT',
	^HLD,3,'HLD',
	^TEVAL,5,0x27,'EVAL',
	^NTIB,4,'#TIB',
	^INN,3,'>IN',
	^TEMP,3,'TMP',
	^BASE,4,'BASE',
	^DOVAR,5,'DOVAR',
	^UPLUS,3,'UM+',
	^XORR,3,'XOR',
	^ORR,2,'OR',
	^ANDD,3,'AND',
	^ZLESS,2,'0<',
	^OVER,4,'OVER',
	^SWAP,4,'SWAP',
	^DUPP,3,'DUP',
	^DROP,4,'DROP',
	^SPSTO,3,'SP!',
	^SPAT,3,'SP@',
	^RPSTO,3,'RP!',
	^TOA,2,'>R',
	^AAT,2,'R@',
	^AFROM,2,'R>',
	^DSHIFT,6,'DSHIFT',
	^PACK,4,'PACK',
	^PAT,2,'P@',
	^PSTORE,2,'P!',
	^AT,1,'@',
	^STORE,1,'!',
	^EXIT,4,'EXIT',
	^EXECU,7,'EXECUTE',
	^BRAN,6,'BRANCH',
	^QBRAN,7,'?BRANCH',
        ^ADONXT,6,'DONEXT',
	^DOLIT,5,'DOLIT',
	^EMIT,4,'EMIT',
	^KEY,3,'KEY',
	0,0,0,0;

/*****************************************
*       BRANCH is rts, next instruction is jump to target
*	it can be a jump machine instruction
*       QBRANCH test ar, then jump to target or next+1
*       EXIT is rts
*       ar is T, ay0 is N, ax0, ax1 and ay1 are scratch
*	DOLIT is DUP followed by ar=literal
*       BRANCH is rts; followed by jump target
*       DONXT is followed by a jump target
*****************************************/

#define pushay0 modify(i0,m3); dm(i0,m0)=ay0;
#define pusharay0 modify(i0,m3); dm(i0,m0)=ay0; ay0=ar;
#define popay0 ay0=dm(i0,m1);
#define popar ar=dm(i0,m1);
#define poparay0 ar=pass ay0,ay0=dm(i0,m1);

HBIT:   ay1=2;
	jump BIT1;
BIT:    ay1=1;
BIT1:   i1=^delay;
	ax0=ar;
	ar=dm(i1,m0);
BIT2:   ar=ar-ay1;
	if gt jump BIT2;
	ar=ax0;
	rts;

{       --      }
STOIO:  set flag_out;
	ax0=ar;
	ar=0;
SIO1:   if flag_in jump SIO1;
SIO2:   ar=ar+1;
	if not flag_in jump SIO2;
	sr=lshift ar by -1 (hi);
	ar=sr1;
	i1=^delay;
	dm(i1,m0)=ar;
	ar=ax0;
	rts;

{      c --      }
EMIT:   reset flag_out;
	call BIT;
	cntr=8;
	do EMIT1 until ce;
	sr=ashift ar by -1 (hi);
	ar=sr1;
	af=pass sr0;
	if eq reset flag_out;
	if ne set flag_out;
	call BIT;
EMIT1:	nop;  
	set flag_out;
	call BIT;
	call BIT;
	poparay0
	rts;

{       -- c     }
KEY:    pusharay0
	toggle fl1;
KEY1:   if flag_in jump KEY1;
	call HBIT;
	call BIT;
	ar=0;
	cntr=8;
	do KEY3 until ce;
	if not flag_in jump KEY2;
	ar=ar+0X100;
KEY2:   sr=ashift ar by -1 (hi);
	ar=sr1;
	call BIT;
KEY3:   nop;
	call BIT;
	CALL BIT;
	rts;

{       -- n     }
DOLIT:
	pushay0
	ay0=ar;
	rts;

{       --      }
BRAN:   rts;

{      f --      }
QBRAN:  i4=toppcstack;
	nop;
	none=pass ar;
	IF eq jump QBR1;
	modify(i4,m5);
QBR1:
	poparay0
	jump(i4);

{       --      }
ADONXT:  ax0=ar;
        ar=dm(i3,m0);
	ar=ar-1;
	if not ac jump ANXT1;
        dm(i3,m0)=ar;
	ar=ax0;
        rts;
ANXT1:   modify(i3,m1);
        ar=toppcstack;
        nop;
        ar=ar+1;
        toppcstack=ar;
        nop;
        ar=ax0;
        rts;

{     a --      }
EXECU:  i4=ar;
	poparay0
	jump(i4);

{       --      }
EXIT:	i4=toppcstack;
	nop;
	nop;
	rts;

{      a -- n     }
AT:	i1=ar;
	ar=dm(i1,m0);
	rts;

{      n a --      }
STORE:  i1=ar;
	dm(i1,m0)=ay0;
	ar=dm(i0,m1);
	ay0=dm(i0,m1);
	rts;

{      pa -- d     }
PAT:    i4=ar;
	pushay0
	ar=pm(i4,m4);
	sr1=0;
	sr0=px;
	sr= sr or lshift ar by -8 (hi);
	ar=sr1;
	ay0=sr0;
	rts;

{      d pa --      }
PSTORE: i4=ar;
	ar=ay0;
	sr=lshift ar by 8 (hi);
	ar=dm(i0,m1);
	px=ar;
	sr=sr or lshift ar by 8 (lo);
	pm(i4,m4)=sr1;
	ar=dm(i0,m1);
	ay0=dm(i0,m1);
	rts;

{      d n -- d     }
DSHIFT: se=ar;
	ar=dm(i0,m1);
	sr0=ay0;
	sr=ashift sr0 (hi);
	sr=sr or lshift ar (lo);
	ar=sr1;
	ay0=sr0;
	rts;

PMERGE:
	ar=pm(i4,m4);
	sr1=0;
	sr0=px;
	sr=sr or lshift ar by 8 (lo);
	px=ay0;
	pm(i4,m4)=sr0;
	rts;

{      va pa --      }
PACK:	i4=ar;
	i1=ay0;
	ay0=dm(i1,m1);
	cntr=ay0;
	call PMERGE;
	af=pass 2;
	do PACK2 until ce;
	ay0=dm(i1,m1);
	call PMERGE;
	af=af-1;
	if eq jump PACK1;
	jump PACK2;
PACK1:	af=pass 3;
	modify(i4,m5);
PACK2:	nop;
	ar=pass af;
	none=ar-3;
	if eq jump PACK4;
	ay0=0;
	af=af-1;
	if gt jump PACK5;
PACK3:	call PMERGE;
PACK4:	ar=dm(i0,m1);
	ay0=dm(i0,m1);
	rts;
PACK5:	call PMERGE;
	jump PACK3;	

{      n --      }
TOR:    i4=toppcstack;
	nop;
	toppcstack=ar;
	poparay0
	jump(i4);

{       -- n     }
RAT:    i4=toppcstack;
	nop;
	pusharay0
	ar=toppcstack;
	nop;
	toppcstack=ar;
	jump(i4);

{       -- n     }
RFROM:  i4=toppcstack;
	nop;
	pusharay0
	ar=toppcstack;
	nop;
	jump(i4);

{      n --      }
TOA:    modify(i3,m3);
        dm(i3,m0)=ar;
	poparay0
        rts;

{       -- n     }
AAT:    pusharay0
        ar=dm(i3,m0);
        rts;

{       -- n     }
AFROM:  pusharay0
        ar=dm(i3,m1);
        rts;

{       --      }
RPSTO:
	rts;

{       -- a     }
SPAT:	modify(i0,m3);
	dm(i0,m3)=ay0;
	ay0=ar;
	dm(i0,m1)=ar;
	ar=i0;
	ar=ar-1;
	rts;

{      a --      }
SPSTO:  i0=ar;
	rts;

{      n -- f     }
ZLESS:  af=pass 0;
	ar=pass ar;
	IF lt  af=pass -1;
	ar=pass af;
	rts;

{      w w -- w     }
ANDD:   ar=ar and ay0, ay0=dm(i0,m1);
	rts;

{      w w -- w     }
ORR:    ar=ar or ay0, ay0=dm(i0,m1);
	rts;

{      w w -- w     }
XORR:   ar=ar xor ay0, ay0=dm(i0,m1);
	rts;

{      w -- w w     }
DUPP:   pusharay0
	rts;

{      w --      }
DROP:   poparay0
	rts;

{      w w -- w w     }
SWAP:   ax0=ar;
	ar=pass ay0, ay0=ax0;
	rts;

{      w1 w2 -- w1 w2 w1     }
OVER:   pusharay0
	ar=dm(i0,m0);
	rts;

{      u u -- d     }
UPLUS:  af=pass 0;
	ar=ar+ay0;
	IF AC  af=pass 1;
	ay0=ar;
	ar=pass af;
	rts;

{       -- a     }
DOVAR:  pusharay0
	ar=toppcstack;
	nop;
	nop;
	rts;

{       -- u     }
BASE:	pusharay0
	ar=^rbase;
	rts;

{       -- a     }
TEMP:	pusharay0
	ar=^rtemp;
	rts;

{       -- a     }
INN:	pusharay0
	ar=^rin;
	rts;

{       -- a     }
NTIB:	pusharay0
	ar=^rntib;
	rts;

{       -- a     }
TEVAL:	pusharay0
	ar=^reval;
	rts;

{       -- a     }
HLD:    pusharay0
	ar=^rhold;
	rts;

{       -- a     }
CNTXT:  pusharay0
	ar=^rcontext;
	rts;

{       -- a     }
NP:     pusharay0
	ar=^rnp;
	rts;

{       -- a     }
CP:	pusharay0
	ar=^rcp;
	rts;

{       -- a     }
VP:     pusharay0
        ar=^rvp;
	rts;

{       -- a     }
LAST:	pusharay0
	ar=^rlast;
	rts;

{       --      }
QDUP:   none=pass ar;
	if eq rts;
	pusharay0
	rts;

{      w1 w2 w3 -- w2 w3 w1     }
ROT:    ax0=dm(i0,m0);
	dm(i0,m0)=ay0;
	ay0=ar;
	ar=ax0;
	rts;

{      d -- d d     }
DDUP:   modify(i0,m3);
	dm(i0,m3)=ay0;
	dm(i0,m0)=ar;
	rts;

{      d --      }
DDROP:  ar=dm(i0,m1);
	ay0=dm(i0,m1);
	rts;

{      n n -- n     }
PLUS:   ar=ar+ay0, ay0=dm(i0,m1);
	rts;

{      w -- w     }
INVER:  ar=not ar ;
	rts;

{      n -- -n     }
NEGAT:  ar=- ar ;
	rts;

{      n -- u     }
ABSS:   ar=abs ar ;
	rts;

{      d -- -d     }
DNEGA:	af=- ay0;
	if eq jump DNEG1;
	ax0=ar;
	ar=pass af;
	ay0=ar;
	ar=not ax0;
	rts;
DNEG1:	ar=- ar;
	rts;

{      d d -- f     }
DEQU:	ay1=dm(i0,m1);
	ax1=dm(i0,m1);
	ar=ar xor ay1;
	if ne jump DEQU1;
	ar=ax1 xor ay0;
	if ne jump DEQU1;
	ar= pass -1;
	popay0
	rts;
DEQU1:	ar=pass 0;
	popay0
	rts;

{      n n -- n     }
SUBB:   ar=ay0-ar, ay0=dm(i0,m1);
	rts;

{      n n -- f     }
LESS:   af=pass 0;
	ar=ay0-ar;
	IF lt af=pass -1;
	ar=pass af;
	popay0
	rts;

{      n n -- f     }
GREAT:  af=pass 0;
	ar=ay0-ar;
	IF gt af=pass -1;
	ar=pass af;
	popay0
	rts;

{      n n -- f     }
EQUAL:  af=pass 0;
	ar=ay0-ar;
	IF eq af=pass -1;
	ar=pass af;
	popay0
	rts;

{      u u -- f     }
ULESS:   af=pass 0;
	ar=ar-ay0;
	IF ac af=pass -1;
	ar=pass af;
	popay0
	rts;

{      n n -- f     }
MAX: 	af=ar-ay0;
	IF lt ar=pass ay0;
	popay0
	rts;

{      n n -- f     }
MIN: 	af=ar-ay0;
	IF gt ar=pass ay0;
	popay0
	rts;

{      n lo hi -- f     }
WITHI:
	call	OVER;
	call	SUBB;
        call    TOA;
	call	SUBB;
        call    AFROM;
	jump	ULESS;

{      ud u -- rem quot     }
UMMOD:  ax0=ar;
	ay1=ay0;
	ay0=dm(i0,m1);
	mr0=ay0, af=pass ay1;
	mr1=ay1, ar=pass ax0;
	astat=0;
	mstat=0x10;
	cntr=17;
	do umm1 until ce;
umm1:   divq ax0;
	mr2=0;
	my0=ax0, ar=pass ay0;
	mr=mr-ar*my0(uu);
	ay0=mr0;
	rts;

{      d n -- rem quot     }
MSMOD:  ax0=ar;
	ay1=ay0;
	ay0=dm(i0,m1);
	mr0=ay0, af=ax0+ay1;
	mr1=ay1, ar=abs ax0;
	mstat=0x10;
	af=abs mr1;
	divs ay1,ar;
	cntr=16;
	do msm1 until ce;
msm1:   divq ar;
	my0=ax0, ar=pass ay0;
	if lt ar=-ay0;
	mr=mr-ar*my0(ss);
	ar=pass ay0;
	ay0=mr0;
	rts;

{      n n -- rem quot     }
SLMOD:  
	call OVER;
	call ZLESS;
	call SWAP;
	jump MSMOD;

{      n n -- quot     }
SLASH:  
	call SLMOD;
	popay0
	rts;

{      n n -- rem     }
MODD:  
	call SLMOD;
	jump DROP;

{      u u -- ud     }
UMSTA:  my0=ay0;
	mr=ar * my0(uu);
	ar=mr1;
	ay0=mr0;
	rts;

{      n n -- n     }
STAR:   my0=ay0;
	mr=ar * my0(ss);
	ar=mr0;
	popay0
	rts;

{      n n -- d     }
MSTAR:  my0=ay0;
	mr=ar * my0(ss);
	ar=mr1;
	ay0=mr0;
	rts;

{      n1 n2 n3 -- rem n1*n2/n3     }
SSMOD:  call    TOA;
	call	MSTAR;
        call    AFROM;
	jump	MSMOD;

{      n1 n2 n3 -- n1*n2/n3     }
STARSL:  call    SSMOD;
	call	SWAP;
	jump	DROP;

CELLS:  sr=ashift ar by 1 (hi);
	ar=sr1;
	rts;

{      n -- n/2     }
TWOSL:  sr=ashift ar by -1 (hi);
	ar=sr1;
	rts;

{      n -- n+1     }
ONEP:	ar=ar+1;
	rts;

{      n -- n-1     }
ONEM:	ar=ar-1;
	rts;

{      n -- n+2     }
CELLP:  ar=ar+2;
	rts;

{      n -- n-2     }
CELLM:  ar=ar-2;
	rts;

{       -- 0     }
ZERO:	pushay0
	ay0=ar, ar=pass 0;
	rts;

{       -- 1     }
ONE:	pushay0
	ay0=ar, ar=pass 1;
	rts;

{       -- -1     }
MONE:	pushay0
	ay0=ar, ar=pass -1;
	rts;

{       -- 32     }
BLANK:	pusharay0
	ar=pass 32;
	rts;

{      n -- c     }
TCHAR:	call	DOLIT;
	ar=0x7F;
	call	ANDD;
	call	DUPP;
	call	BLANK;
	call	DOLIT;
	ar=0x7f;
	call	WITHI;
	call	QBRAN;
	jump	TCHA1;
	rts;
TCHA1:  call    DROP;
	call	DOLIT;
	ar=0x5f;
	rts;

{       -- n     }
DEPTH:  ay1=i0;
	pusharay0
	ar=bottom;
	ar=ar-ay1;
	rts;

{      u -- n     }
PICK:	m2=ar;
	modify(i0,m3);
	dm(i0,m0)=ay0;
	i1=i0;
	modify(i1,m2);
	ar=dm(i1,m0);
	modify(i0,m1);
	rts;

{      n a --      }
PSTOR:  i1=ar;
	ar=dm(i1,m0);
	ar=ar+ay0;
	dm(i1,m0)=ar;
	ar=dm(i0,m1);
	popay0
	rts;

{      a -- d      }
DAT:    i1=ar;
	ar=dm(i1,m1);
	modify(i0,m3);
	dm(i0,m0)=ay0;
	ay0=dm(i1,m0);
	rts;

{      d a --      }
DSTOR:  i1=ar;
	dm(i1,m1)=ay0;
	ar=dm(i0,m1);
	dm(i1,m0)=ar;
	ar=dm(i0,m1);
	popay0
	rts;

{      a -- a+1 n     }
COUNT:	modify(i0,m3);
	dm(i0,m0)=ay0;
	i4=ar;
	ar=ar+1;
	ay0=ar;
	ar=dm(i4,m4);
	rts;

{      a -- a+1 c     }
COUNTC:	modify(i0,m3);
	dm(i0,m0)=ay0;
	i4=ar;
	ar=ar+1;
	ay0=ar;
	ar=dm(i4,m4);
	ay1=0x1f;
	ar=ar and ay1;
	rts;

{       -- a     }
HERE:   call    NP;
	jump	AT;

{       -- a     }
THERE:   call    CP;
	jump	AT;

{       -- a     }
VHERE:   call    VP;
	jump	AT;

{       -- a     }
PAD:    call    VP;
        call    AT;
	call	DOLIT;
	ar=80;
        jump    PLUS;

{       -- a     }
TIB:    call    DOLIT;
	ar=^rtib;
	jump	AT;

{      a --      }
ATEXE:  i1=ar;
	ar=dm(i1,m0);
	i4=ar;
	poparay0
	jump(i4);

{      a a u --      }
CMOVE:  ax0=dm(i0,m1);
	i2=ax0;
	none=pass ar;
	if eq jump CMV2;	
	cntr=ar;
	i1=ay0;
	do CMV1 until ce;
	ar=dm(i2,m1);
CMV1:   dm(i1,m1)=ar;
CMV2:   ar=dm(i0,m1);
	popay0
	rts;

{      a u n --      }
FILL:   ax0=dm(i0,m1);
	i1=ax0;
	none=pass ay0;
	if eq jump FIL2;	
	cntr=ay0;
	do FIL1 until ce;
FIL1:   dm(i1,m1)=ar;
FIL2:   ar=dm(i0,m1);
	popay0
	rts;

{      a u --      }
ERASE:  call    ZERO;
	jump    FILL;

{      a u a --      }
PACKS:
	call	DUPP;
        call    TOA;
	call	DDUP;
	call	STORE;
	call	ONEP;
	call	SWAP;
	call	CMOVE;
        call    AFROM;
	rts;

{      n -- c     }
DIGIT:	af=pass 9;
	ay1=0x30;
	none=ar-af;
	if le jump DIGT1;
	ay1=0x37;
DIGT1:  ar=ar+ay1;
	rts;

{      u base -- u c     }
EXTRC:	call	ZERO;
	call	SWAP;
	call	UMMOD;
	call	SWAP;
	jump	DIGIT;

{       --      }
BDIGS:	call	PAD;
	call	HLD;
	jump	STORE;

{      c --      }
HOLD:	call	HLD;
	call	AT;
	call	ONEM;
	call	DUPP;
	call	HLD;
	call	STORE;
	jump	STORE;

{      u -- u     }
DIG:	call	BASE;
	call	AT;
	call	EXTRC;
	jump	HOLD;

{      u -- 0     }
DIGS:	call	DIG;
	call	DUPP;
	call	QBRAN;
	jump	DIGS1;
	jump	DIGS;
DIGS1:	rts;

{      n --      }
SIGN:	call	ZLESS;
	call	QBRAN;
	jump	SIGN1;
	call	DOLIT;
	ar=0x2D;
	jump	HOLD;
SIGN1:	rts;

{      u -- a u    }
EDIGS:	call	DROP;
	call	HLD;
	call	AT;
	call	PAD;
	call	OVER;
	jump	SUBB;

{      n -- a u     }
STR:	call	DUPP;
	call	TOA;
	call	ABSS;
	call	BDIGS;
	call	DIGS;
	call	AFROM;
	call	SIGN;
	jump	EDIGS;

{       --      }
HEX:	call	DOLIT;
	ar=16;
	call	BASE;
	jump	STORE;

{       --      }
DECIM:	call	DOLIT;
	ar=10;
	call	BASE;
	jump	STORE;

{      c base -- u f     }
DIGTQ:  call    TOA;
	call	DOLIT;
	ar=0x30;
	call	SUBB;
	call	DOLIT;
	ar=9;
	call	OVER;
	call	LESS;
	call	QBRAN;
	jump	DGTQ1;
	call	DOLIT;
	ar=	7;
	call	SUBB;
	call	DUPP;
	call	DOLIT;
	ar=	10;
	call	LESS;
	call	ORR;
DGTQ1:	call	DUPP;
        call    AFROM;
	jump	ULESS;

{      a -- n T | a F     }
NUMBQ:
	call	BASE;
	call	AT;
        call    TOA;
	call	ZERO;
	call	OVER;
	call	COUNT;
	call	OVER;
	call	AT;
	call	DOLIT;
	ar=     0x24;
	call	EQUAL;
	call	QBRAN;
	jump	NUMQ1;
	call	HEX;
	call	SWAP;
	call	ONEP;
	call	SWAP;
	call	ONEM;
NUMQ1:	call	OVER;
	call	AT;
	call	DOLIT;
	ar=     0x2D;
	call	EQUAL;
        call    TOA;
	call	SWAP;
	call	AAT;
	call	SUBB;
	call	SWAP;
	call	AAT;
	call	PLUS;
	call	QDUP;
	call	QBRAN;
	jump	NUMQ6;
	call	ONEM;
        call    TOA;
NUMQ2:	call	DUPP;
        call    TOA;
	call	AT;
	call	BASE;
	call	AT;
	call	DIGTQ;
	call	QBRAN;
	jump	NUMQ4;
	call	SWAP;
	call	BASE;
	call	AT;
	call	STAR;
	call	PLUS;
        call    AFROM;
	call	ONEP;
        call    ADONXT;
	jump	NUMQ2;
	call	AAT;
	call	SWAP;
	call	DROP;
	call	QBRAN;
	jump	NUMQ3;
	call	NEGAT;
NUMQ3:	call	SWAP;
	jump	NUMQ5;
NUMQ4:  call    AFROM;
        call    AFROM;
	call	DDROP;
	call	DDROP;
	call	ZERO;
NUMQ5:	call	DUPP;
NUMQ6:  call    AFROM;
	call	DDROP;
        call    AFROM;
	call	BASE;
	jump	STORE;

{       --      }
SPACE:
	call	BLANK;
	jump	EMIT;

{      u --      }
SPACS:
	call	ZERO;
	call	MAX;
        call    TOA;
	jump	CHAR2;
CHAR1:	call	SPACE;
CHAR2:  call    ADONXT;
	jump	CHAR1;
	rts;

{      a u --      }
TYPES:  call    TOA;
	jump	TYPE2;
TYPE1:	call	DUPP;
	call	AT;
	call	EMIT;
	call	ONEP;
TYPE2:  call    ADONXT;
	jump	TYPE1;
	jump	DROP;

{       --      }
CR:
	call	DOLIT;
	ar=	CRR;
	call	EMIT;
	call	DOLIT;
	ar=	LF;
	jump	EMIT;

{       --      }
DOSTR:	rts;

{       --      }
STRQP:  rts;

{      a --      }
DOTQP:	call	COUNT;
	jump	TYPES;

{       --      }
DOTR:
        call    TOA;
	call	STR;
        call    AFROM;
	call	OVER;
	call	SUBB;
	call	SPACS;
	jump	TYPES;

{      u u --      }
UDOTR:
        call    TOA;
	call	BDIGS;
	call	DIGS;
	call	EDIGS;
        call    AFROM;
	call	OVER;
	call	SUBB;
	call	SPACS;
	jump	TYPES;

{      u --      }
UDOT:
	call	BDIGS;
	call	DIGS;
	call	EDIGS;
	call	SPACE;
	jump	TYPES;

{      n --      }
DOT:
	call	BASE;
	call	AT;
	call	DOLIT;
	ar=	10;
	call	XORR;
	call	QBRAN;
	jump	DOT1;
	jump	UDOT;
DOT1:	call	STR;
	call	SPACE;
	jump	TYPES;

{      a -- n     }
QUEST:
	call	AT;
	jump	DOT;

{      a u c -- a u delta     }
PARS:
	call	TEMP;
	call	STORE;
	call	OVER;
        call    TOA;
	call	DUPP;
	call	QBRAN;
	jump	PARS8;
	call    ONEM;
	call	TEMP;
	call	AT;
	call	BLANK;
	call	EQUAL;
	call	QBRAN;
	jump	PARS3;
        call    TOA;
PARS1:	call	BLANK;
	call	OVER;
	call	AT;
	call	SUBB;
	call	ZLESS;
	call	INVER;
	call	QBRAN;
	jump	PARS2;
	call	ONEP;
        call    ADONXT;
	jump	PARS1;
        call    AFROM;
	call	DROP;
	call	ZERO;
	jump	DUPP;
PARS2:  call    AFROM;
PARS3:	call	OVER;
	call	SWAP;
        call    TOA;
PARS4:	call	TEMP;
	call	AT;
	call	OVER;
	call	AT;
	call	SUBB;
	call	TEMP;
	call	AT;
	call	BLANK;
	call	EQUAL;
	call	QBRAN;
	jump	PARS5;
	call	ZLESS;
PARS5:	call	QBRAN;
	jump	PARS6;
	call	ONEP;
        call    ADONXT;
	jump	PARS4;
	call	DUPP;
        call    TOA;
	jump	PARS7;
PARS6:  call    AFROM;
	call	DROP;
	call	DUPP;
	call	ONEP;
        call    TOA;
PARS7:	call	OVER;
	call	SUBB;
        call    AFROM;
        call    AFROM;
	jump	SUBB;
PARS8:	call	OVER;
        call    AFROM;
	jump	SUBB;

{      c -- a u     }
PARSE:
        call    TOA;
	call	TIB;
	call	INN;
	call	AT;
	call	PLUS;
	call	NTIB;
	call	AT;
	call	INN;
	call	AT;
	call	SUBB;
        call    AFROM;
	call	PARS;
	call	INN;
	jump	PSTOR;

{       --      }
DOTPR:
	call	DOLIT;
	ar=     0X29;
	call	PARSE;
	jump	TYPES;

{       --      }
PAREN:
	call	DOLIT;
	ar=     0X29;
	call	PARSE;
	jump	DDROP;

{       --      }
BKSLA:
	call	NTIB;
	call	AT;
	call	INN;
	jump	STORE;

{      c --      }
WORDD:
	call	PARSE;
	call    NP;
	call    AT;
	call    OVER;
	call    SUBB;
	jump	PACKS;

{       -- a     }
TOKEN:
	call	BLANK;
	jump	WORDD;

{      na -- cpa     }
NAMET:
	jump    ONEM;

{      a va -- ca na | a F     }
FIND:
	call    DUPP;
	call    AT;
	call    QBRAN;
	jump    FIND5;
	call    ONEP;
FIND1:  call    DDUP;
	call    AT;
	call    DOLIT;
	ar=0x1f;
	call    ANDD;
	call    SWAP;
	call    AT;
	call    XORR;
	call    QBRAN;
	jump    FIND2;
	call    COUNT;
	call    DOLIT;
	ar=0x1f;
	call    ANDD;
       call    PLUS;
	jump    FIND;
FIND2:  call    OVER;
	call    COUNT;
        call    TOA;
	call    OVER;
	call    ONEP;
	jump    FIND4;
FIND3:  call    SWAP;
	call    COUNT;
        call    TOA;
	call    SWAP;
	call    COUNT;
        call    AFROM;
	call    XORR;
	call    QBRAN;
	jump    FIND4;
	call    DDROP;
        call    AFROM;
	call    DROP;
	call    COUNTC;
	call    PLUS;
	jump    FIND;
FIND4:  call    ADONXT;
	jump    FIND3;
	call    DDROP;
	call	SWAP;
	call    DROP;
	call    DUPP;
	call    ONEM;
	call 	AT;
	jump    SWAP;
FIND5:
	jump    AT;

{      a -- na ca | a F     }
NAMEQ:
	call	CNTXT;
	call    AT;
	jump	FIND;

{      bot eot cur -- bot eot cur}
BKSP:
        call    TOA;
	call	OVER;
        call    AFROM;
	call	SWAP;
	call	OVER;
	call	XORR;
	call	QBRAN;
	jump	BACK1;
	call	DOLIT;
	ar=	BKSPP;
	call	EMIT;
	call	ONEM;
	call	BLANK;
	call	EMIT;
	call	DOLIT;
	ar=	BKSPP;
	jump	EMIT;
BACK1:	rts;

{      bot eot cur c -- bot eot cur}
TAP:
	call	DUPP;
	call	EMIT;
	call	OVER;
	call	STORE;
	jump	ONEP;

{      bot eot cur c -- bot eot cur}
KTAP:
	call	DUPP;
	call	DOLIT;
	ar=	CRR;
	call	XORR;
	call	QBRAN;
	jump	KTAP2;
	call	DOLIT;
	ar=	BKSPP;
	call	XORR;
	call	QBRAN;
	jump	KTAP1;
	call	BLANK;
	jump	TAP;
KTAP1:	jump	BKSP;
KTAP2:	call	DROP;
	call	SWAP;
	call	DROP;
	jump	DUPP;

{      a u -- a u     }
ACCEP:
	call	OVER;
	call	PLUS;
	call	OVER;
ACCP1:	call	DDUP;
	call	XORR;
	call	QBRAN;
	jump	ACCP4;
	call	KEY;
	call	DUPP;
	call	BLANK;
	call	DOLIT;
	ar=	127;
	call	WITHI;
	call	QBRAN;
	jump	ACCP2;
	call	TAP;
	jump	ACCP3;
ACCP2:	call	KTAP;
ACCP3:	jump	ACCP1;
ACCP4:	call	DROP;
	call	OVER;
	jump	SUBB;

{       --      }
QUERY:
	call	TIB;
	call	DOLIT;
	ar=	80;
	call	ACCEP;
	call	NTIB;
	call	STORE;
	call	DROP;
	call	ZERO;
	call	INN;
	jump	STORE;

{       --      }
ABORT:  call    PRESE;
RPST0:  ax0=ar;
	pop pc;  
	ar=sstat;
	ay1=1;
	none=ar and ay1;
	if eq jump RPST0;
RPST1:	pop cntr;  
	ar=sstat;
	ay1=4;
	none=ar and ay1;
	if eq jump RPST1;
RPST2:	pop sts;  
	ar=sstat;
	ay1=0x10;
	none=ar and ay1;
	if eq jump RPST2;
RPST3:	pop loop;  
	ar=sstat;
	ay1=0x40;
	none=ar and ay1;
	if eq jump RPST3;
	ar=ax0;
	mstat=0x10;
	jump	QUIT;

{      f a --      }
ABORQ:  call    SWAP;
	call	QBRAN;
	jump	ABOR2;
ABOR1:	call	SPACE;
	call	COUNT;
	call	TYPES;
	call	DOLIT;
	ar=     0X3F;
	call	EMIT;
	call	CR;
	jump	ABORT;
ABOR2:  jump	DROP;

{      a --      }
INTER:
	call	NAMEQ;
	call	QDUP;
	call	QBRAN;
	jump	INTE1;
	call	AT;
	call	DOLIT;
	ar=      COMPO;
	call	ANDD;
	call    DOLIT;
	ar=^MCOMPILE;
	call	ABORQ;
	jump	EXECU;
INTE1:	call	NUMBQ;
	call	QBRAN;
	jump	ABOR1;
	rts;

{       --      }
LBRAC:
	call	DOLIT;
	ar=	^INTER;
	call	TEVAL;
	jump	STORE;

{       --      }
DOTOK:
	call	DOLIT;
	ar=	^INTER;
	call	TEVAL;
	call	AT;
	call	EQUAL;
	call	QBRAN;
	jump	DOTO1;
	call    DOLIT;
	ar=^MOK;
	call	DOTQP;
DOTO1:	jump	CR;

{       --      }
QSTAC:
	call	DEPTH;
	call	ZLESS;
	call    DOLIT;
	ar=^MUNDER;
	call	ABORQ;
	rts;

{       --      }
EVAL:
EVAL1:	call	TOKEN;
	call	DUPP;
	call	AT;
	call	QBRAN;
	jump	EVAL2;
	call	TEVAL;
	call	ATEXE;
	call	QSTAC;
	jump	EVAL1;
EVAL2:	call	DROP;
	jump	DOTOK;

{       --      }
PRESE:
	call	DOLIT;
	ar=bottom;
	call    SPSTO;
	call	DOLIT;
	ar=^terminal;
	call    DOLIT;
	ar=^ntib;
	jump	STORE;

{       --      }
QUIT:
QUIT1:	call	LBRAC;
QUIT2:	call	QUERY;
	call	EVAL;
	jump	QUIT2;

{       -- ca     }
TICK:
	call	TOKEN;
	call	NAMEQ;
	call    QBRAN;
	jump	ABOR1;
	rts;	

{      u --      }
ALLOT:
	call	CP;
	jump	PSTOR;

{      u --      }
VALLOT:
        call    VP;
	jump	PSTOR;

{      d --      }
COMMA:
	call	THERE;
	call	DUPP;
	call	ONEP;
	call	CP;
	call	STORE;
	call	PSTORE;
	rts;	

{      n --      }
NCOMMA:
	call	ZERO;
	call	DOLIT;
	ar=4;
	call	DSHIFT;
	call	DOLIT;
	ar=0x40;
	call	ORR;
	call	SWAP;
	call	DOLIT;
	ar=0xA;
	call	ORR;
	call	SWAP;
	jump	COMMA;

{      a --      }
CALLC:
	call	ZERO;
	call	DOLIT;
	ar=4;
	call	DSHIFT;
	call	DOLIT;
	ar=0x1C;
	call	ORR;
	call	SWAP;
	call	DOLIT;
	ar=0xF;
	call	ORR;
	call	SWAP;
	jump	COMMA;

{      a --      }
JUMPC:
	call	ZERO;
	call	DOLIT;
	ar=4;
	call	DSHIFT;
	call	DOLIT;
	ar=0x18;
	call	ORR;
	call	SWAP;
	call	DOLIT;
	ar=0xF;
	call	ORR;
	call	SWAP;
	jump	COMMA;

{      a a --      }
JUMPST: call    TOA;
	call	ZERO;
	call	DOLIT;
	ar=4;
	call	DSHIFT;
	call	DOLIT;
	ar=0x18;
	call	ORR;
	call	SWAP;
	call	DOLIT;
	ar=0xF;
	call	ORR;
	call	SWAP;
        call    AFROM;
	jump	PSTORE;

{       --      }
BCOMP:
	call	TICK;
	jump	CALLC;

{       --      }
COMPI:
	call	RFROM;
	call	DUPP;
	call	PAT;
	call	COMMA;
	call	ONEP;
        call    TOR;
        rts;

{      n --      }
LITER:
	call	COMPI;
	call	DOLIT;
	jump	NCOMMA;

{       --      }
STRCQ:  call    VP;
        call    AT;
        call    LITER;
	call	DOLIT;
	ar=0X22;
	call	WORDD;
        call    COUNT;
        call    VP;
	call	AT;
        call    PACKS;
        call    COUNT;
        call    PLUS;
	call	ONEP;
        call    VP;
	jump	STORE;

{       -- a     }
FOR:
	call	COMPI;
	call	TOA;
	jump	THERE;

{      a --      }
NEXT:
	call	COMPI;
	call	ADONXT;
	jump	JUMPC;

{       -- a     }
BEGINN:
	jump	THERE;

{      a --      }
UNTILL:
	call	COMPI;
	call	QBRAN;
	jump	JUMPC;

{      a --      }
AGAINN:
	jump	JUMPC;

{       -- a     }
IFF:
	call	COMPI;
	call	QBRAN;
	jump	AHEAD;

{      a --      }
THENN:
	call	THERE;
	call	SWAP;
	jump	JUMPST;

{      a1 -- a2     }
ELSEE:
	call	AHEAD;
	call	SWAP;
	call	THERE;
	call	SWAP;
	jump	JUMPST;

{       -- a     }
AHEAD:
	call	THERE;
	call	ZERO;
	call	DUPP;
	jump	COMMA;

{       a1 -- a2     }
WHILE:
	call	COMPI;
	call	QBRAN;
	call	AHEAD;
	jump	SWAP;

{      a1 a2 --      }
REPEA:
	call	JUMPC;
	call	THERE;
	call	SWAP;
	jump	JUMPST;

{      a1 -- a2     }
AFT:
	call	DROP;
	call	AHEAD;
	call	THERE;
	jump	SWAP;

{       --      }
ABRTQ:  call    STRCQ;
	call	COMPI;
	call	ABORQ;
        rts;

{       --      }
STRQ:   jump    STRCQ;

{       --      }
DOTQ:   call    STRCQ;
	call	COMPI;
        call    COUNT;
        call    COMPI;
        call    TYPES;
        rts;

{      a -- a     }
UNIQU:
	call	DUPP;
	call	NAMEQ;
	call	QBRAN;
	jump	UNIQ1;
	call    DOLIT;
	ar=^MREDEF;
	call	DOTQP;
	call	OVER;
	call	COUNTC;
	call	TYPES;
UNIQ1:	jump	DROP;

{      na --      }
SNAME:
	call	DUPP;
	call	AT;
	call	QBRAN;
	jump	PNAM1;
	call	UNIQU;
	call	DUPP;
	call	CELLM;
	call	NP;
	call	STORE;
	call	ONEM;
	call	THERE;
	call	OVER;
	call	STORE;
	call	LAST;
	jump	STORE;
PNAM1:  call    DOLIT;
	ar=^MNAME;
	jump	ABOR1;

{      a --      }
SCOMP:
	call	NAMEQ;
	call	QDUP;
	call	QBRAN;
	jump	SCOM2;
	call	AT;
	call	DOLIT;
	ar=IMEDD;
	call	ANDD;
	call	QBRAN;
	jump	SCOM1;
	jump	EXECU;
SCOM1:	jump	CALLC;
SCOM2:	call	NUMBQ;
	call	QBRAN;
	jump	ABOR1;
	jump	LITER;

{       --      }
OVERT:
	call	LAST;
	call	AT;
	call	CNTXT;
	jump	STORE;

{       --      }
SEMIS:
	call	COMPI;
	rts;
	call	LBRAC;
	jump	OVERT;

{       --      }
RBRAC:
	call	DOLIT;
	ar=	^SCOMP;
	call	TEVAL;
	jump	STORE;

{       --      }
COLON:
	call	TOKEN;
	call	SNAME;
	jump	RBRAC;

{       --      }
IMMED:
	call	DOLIT;
	ar=IMEDD;
	call	LAST;
	call	AT;
	call	AT;
	call	ORR;
	call	LAST;
	call	AT;
	jump	STORE;

{       --      }
CREAT:
	call	TOKEN;
	call	SNAME;
	call	OVERT;
	call	COMPI;
        call    DOLIT;
        call    VP;
        call    AT;
        call    NCOMMA;
        call    COMPI;
        rts;
	rts;

{       --      }
VARIA:
	call	CREAT;
        call    ONE;
        call    VP;
        jump    PSTOR;

{      a u --      }
UTYPE:
        call    TOA;
	jump	UTYP2;
UTYP1:  call    DUPP;
	call	AT;
	call    ZERO;
	call    DOLIT;
	ar=256;
	call    UMMOD;
	call	TCHAR;
	call	EMIT;
	call    TCHAR;
	call    EMIT;
	call	ONEP;
UTYP2:  call    ADONXT;
	jump	UTYP1;
	jump	DROP;

{      a u -- a u     }
{      a u -- a u     }
DUMPP:
	call	OVER;
	call	DOLIT;
	ar=     5;
	call	UDOTR;
	call	SPACE;
        call    TOA;
	jump	PDUM2;
PDUM1:	call	DUPP;
	call	AT;
	call	DOLIT;
	ar=     5;
	call	UDOTR;
	call	ONEP;
PDUM2:  call    ADONXT;
	jump	PDUM1;
	rts;

{      a u --      }
DUMP:
	call	BASE;
	call	AT;
        call    TOA;
	call	HEX;
	call	DOLIT;
	ar=     8;
	call	SLASH;
        call    TOA;
DUMP1:	call	CR;
	call	DOLIT;
	ar=     8;
	call	DDUP;
	call	DUMPP;
	call	ROT;
	call	ROT;
	call	SPACE;
	call	SPACE;
	call	UTYPE;
        call    ADONXT;
	jump	DUMP1;
DUMP3:	call	DROP;
        call    AFROM;
	call	BASE;
	jump	STORE;

{      pa u -- pa u     }
PDUMPP:
	call	OVER;
	call	DOLIT;
	ar=     5;
	call	UDOTR;
	call	SPACE;
        call    TOA;
	jump	PPDUM2;
PPDUM1:	call	DUPP;
	call	PAT;
	call	DOLIT;
	ar=     3;
	call	UDOTR;
	call	DOLIT;
	ar=     4;
	call	UDOTR;
	call	ONEP;
PPDUM2: call    ADONXT;
	jump	PPDUM1;
	rts;

{      pa u --      }
PDUMP:
	call	BASE;
	call	AT;
        call    TOA;
	call	HEX;
	call	DOLIT;
	ar=     8;
	call	SLASH;
        call    TOA;
PDUMP1:	call	CR;
	call	DOLIT;
	ar=     8;
	call	PDUMPP;
        call    ADONXT;
	jump	PDUMP1;
PDUMP3:	call	DROP;
        call    AFROM;
	call	BASE;
	jump	STORE;

{       --      }
DOTS:
	call	CR;
	call	DEPTH;
        call    TOA;
	jump	DOTS2;
DOTS1:	call	AAT;
	call	PICK;
	call	DOT;
DOTS2:	call	ADONXT;
	jump	DOTS1;
	call    DOLIT;
	ar=^MSP;
	call	DOTQP;
	rts;

{      ca -- na | F    }
TNAME:
	call	CNTXT;
	call	AT;
TNAM2:
	call	DUPP;
	call	AT;
	call	QBRAN;
	jump	TNAM4;
	call	DDUP;
	call	AT;
	call	XORR;
	call	QBRAN;
	jump	TNAM3;
	call	ONEP;
	call	COUNTC;
	call	PLUS;
	jump	TNAM2;
TNAM3:	call	ONEP;
	popay0
	rts;
TNAM4:	call	DDROP;
	jump	ZERO;

{      na --      }
DOTID:
	call	QDUP;
	call	QBRAN;
	jump	DOTI1;
	call	COUNTC;
	jump    TYPES;
DOTI1:  call    DOLIT;
	ar=^MNONAME;
	call	DOTQP;
	rts;

{      d -- a     }
ADDR:	ar=ar or 4;
        ay1=0x1c;
        none=ar-ay1;
        if ne jump ADDR1;
	ar=ay0;
        sr=lshift ar by -4 (lo);
	ar=sr0;
	jump ADDR2;
ADDR1:	ar=0;
ADDR2:	popay0
	rts;

{       --      }
SEE:	call	BASE;
	call	AT;
	call	TOA;
	call	HEX;
	call	TICK;
	call	CR;
	call	ONEM;
	cntr=40;
	do SEE4 until ce;
SEE1:	call	ONEP;
	call	DUPP;
	call	PAT;
	call	ADDR;
	call	DUPP;
	call	QBRAN;
	jump	SEE2;

	call	TNAME;
SEE2:	call	QDUP;
	call	QBRAN;
	jump	SEE3;
	call	SPACE;
	call	DOTID;
	jump	SEE4;
SEE3:	call	DUPP;
	call	PAT;
	call	DOLIT;
        ar=3;
	call	UDOTR;
	call	DOLIT;
        ar=4;
	call	UDOTR;
SEE4:   nop;
	call	AFROM;
	call	BASE;
	call	STORE;
	jump	DROP;

{       --      }
WORDS:
	call	CR;
	call	CNTXT;
	call	AT;
WORS1:
	call	DUPP;
	call	AT;
	call	QBRAN;
	jump	WORS2;
	call	ONEP;
	call	DUPP;
	call	SPACE;
	call	DOTID;
	call	COUNTC;
	call	PLUS;
	jump    WORS1;
WORS2:	jump	DROP;

{       --      }
FRGT:	call	TICK;
	call	DUPP;
	call	DOLIT;
	ar=^COLD;
	call	GREAT;
	call	QBRAN;
	jump	FRGT1;
	call	DUPP;
	call	CP;
	call	STORE;
	call	TNAME;
	call	COUNTC;
	call	PLUS;
	call	DUPP;
	call	LAST;
	call	STORE;
	call	OVERT;
	call	ONEM;
	call	NP;
	jump	STORE;
FRGT1:
	call	DOLIT;
	ar=^FENCE;
	call	COUNT;
	jump	TYPES;

{       --      }
HII:
	call	CR;
	call    DOLIT;
	ar=^MVERSION;
	call	DOTQP;
	jump	CR;

{       -- a     }
TBOOT:
	call	DOLIT;
	ar=	^HII;
	RTS;

{       --      }
COLD:
COLD1:
	imask=0;
	icntl=0;
	mstat=0x10;
	ax0=0;
        dm(0x3FFF)=ax0;
	ar=0;
	ay0=0;
	i0=^datastack;
	l0=%datastack; l1=0; l2=0;
	i3=^astack;
        l3=%astack;
	l4=0; l5=0; l6=0; l7=0;
	m0=0; m1=1; m2=0; m3=-1;
	m4=0; m5=1; m6=0; m7=-1;
	pop sts, pop cntr, pop pc, pop loop;
	pop sts, pop cntr, pop pc, pop loop;
	pop sts, pop cntr, pop pc, pop loop;
	pop sts, pop cntr, pop pc, pop loop;
	ena m_mode;
	dis ints;
	call	TBOOT;
	call	EXECU;
	call	OVERT;
	jump    ABORT;

CPP:	rts;

.endmod;



