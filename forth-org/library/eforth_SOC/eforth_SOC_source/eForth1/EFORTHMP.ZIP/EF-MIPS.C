cat calling.c
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <gl/gl.h>

int main()
{   extern int eForth();
    printf("Boot eForth from C\n");
    printf("C. H. Ting, 1993\n");
    
    eForth();
    return 0;
}
<113 weaver2 /work/ls> 